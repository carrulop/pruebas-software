package acme;

  import java.util.stream.Stream;
  import org.junit.jupiter.params.provider.Arguments;

  public class DatosPruebaFactory {
    public static Stream<Arguments> generarCadenasVacias() {
	 return Stream.of(Arguments.of("", true),
	 		Arguments.of(null, true),
			Arguments.of("   ", true),
			Arguments.of("No vacía", false));
    }
  }
