package acme;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.ArgumentsSource;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EmptySource;
import org.junit.jupiter.params.provider.FieldSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

public class CadenasTest {

	@ParameterizedTest(name = "El valor <{0}> deberia ser blanco")
	@ValueSource(strings = { "    " })
	@NullSource
	@EmptySource
	void testEsBlancoRetornaTrueSiEsVacia(String entrada) {
		Cadenas cadenas = new Cadenas();
		assertTrue(cadenas.esBlanco(entrada));
	}

	@ParameterizedTest(name = "La cadena {0} en mayúsculas debería" + " ser {1} ")
	@CsvSource({ "java,JAVA", "Java,JAVA", "JAVa,JAVA" })
	void testPasarMayusculaDeberiaFuncionarCorrectamente(String entrada, String valorEsperado) {
		Cadenas cadenas = new Cadenas();
		assertEquals(valorEsperado, cadenas.pasarMayusculas(entrada));
	}

	@ParameterizedTest(name = "La cadena {0} en mayúsculas debería" + " ser {1} ")
	@CsvSource(value = { "java:JAVA", "Java:JAVA", "JAVa:JAVA" }, delimiter = ':')
	void testPasarMayusculaDeberiaFuncionarCorrectamenteConDelimitador(String entrada, String valorEsperado) {
		Cadenas cadenas = new Cadenas();
		assertEquals(valorEsperado, cadenas.pasarMayusculas(entrada));
	}

	@ParameterizedTest(name = "La cadena {0} en mayúsculas debería" + " ser {1} ")
	@CsvFileSource(resources = { "/datosCadenas.csv" }, delimiter = ':', nullValues = { "nulo" }, numLinesToSkip = 1)
	void testPasarMayusculaDeberiaFuncionarCorrectamenteUsandoArchivoCsv(String entrada, String valorEsperado) {
		Cadenas cadenas = new Cadenas();
		assertEquals(valorEsperado, cadenas.pasarMayusculas(entrada));
	}

	@ParameterizedTest
	@MethodSource("generarDatosPrueba")
	void testCadenaVacia(String entrada, boolean valorEsperado) {
		Cadenas cadenas = new Cadenas();
		assertEquals(valorEsperado, cadenas.esBlanco(entrada));
	}

	private static Stream<Arguments> generarDatosPrueba() {
		return Stream.of(Arguments.of("", true), Arguments.of(null, true), Arguments.of("   ", true),
				Arguments.of("No vacía", false));
	}

	@ParameterizedTest
	@MethodSource
	void testCadenaVacia2(String input, boolean valorEsperado) {
		Cadenas cadenas = new Cadenas();
		assertEquals(valorEsperado, cadenas.esBlanco(input));
	}

	private static Stream<Arguments> testCadenaVacia2() {
		return Stream.of(Arguments.of("", true), Arguments.of(null, true), Arguments.of("   ", true),
				Arguments.of("No vacía", false));
	}

	@ParameterizedTest
	@MethodSource
	void testCadenaVaciaDeberiaRetornarTrue(String input) {
		Cadenas cadenas = new Cadenas();
		assertTrue(cadenas.esBlanco(input));
	}

	private static Stream<String> testCadenaVaciaDeberiaRetornarTrue() {
		return Stream.of("", null, "   ");
	}

	@ParameterizedTest
	@MethodSource("acme.DatosPruebaFactory#generarCadenasVacias")
	void testMetodo(String cadena, boolean valorEsperado) {
		Cadenas cadenas = new Cadenas();
		assertEquals(valorEsperado, cadenas.esBlanco(cadena));
	}

	static List<String> cadenasVacias = Arrays.asList("", null, "   ");

	@ParameterizedTest(name = "El valor <{0}> deberia ser blanco")
	@FieldSource("cadenasVacias")
	void testEsBlancoRetornaTrueSiEsVaciaConFieldSource(String entrada) {
		Cadenas cadenas = new Cadenas();
		assertTrue(cadenas.esBlanco(entrada));
	}

	static List<Arguments> testCadenaVaciaRetornaTrue = Arrays.asList(Arguments.of("", true), Arguments.of(null, true),
			Arguments.of("   ", true), Arguments.of("No vacía", false));

	@ParameterizedTest
	@FieldSource
	void testCadenaVaciaRetornaTrue(String input, boolean esperado) {
		Cadenas cadenas = new Cadenas();
		assertEquals(esperado, cadenas.esBlanco(input));
	}

	@ParameterizedTest
	@ArgumentsSource(CadenaEsBlancoArgumentProvider.class)
	void testCadenaVaciaConArgumentsSource(String input, boolean valorEsperado) {
		Cadenas cadenas = new Cadenas();
		assertEquals(valorEsperado, cadenas.esBlanco(input));
	}

	static Stream<Arguments> argumentos = Stream.of(Arguments.of("", true), Arguments.of(null, true),
			Arguments.of("   ", true), Arguments.of("No vacío", false));

	@ParameterizedTest
	@VariableSource("argumentos")
	void testCadenaVaciaConVariableSource(String input, boolean valorEsperado) {
		Cadenas cadenas = new Cadenas();
		assertEquals(valorEsperado, cadenas.esBlanco(input));
	}

	static List<Arguments> vacios() {
		return Arrays.asList(Arguments.of("", true), Arguments.of(null, true), Arguments.of("   ", true));
	}

	static List<Arguments> noVacios() {
		return Arrays.asList(Arguments.of("No Vacío", false), Arguments.of("Prueba", false));
	}

	@ParameterizedTest
	@MethodSource("vacios")
	@MethodSource("noVacios")
	void testCadenaVaciaConMultiplesMethodSources(String entrada, boolean valorEsperado) {
		Cadenas cadenas = new Cadenas();
		assertEquals(valorEsperado, cadenas.esBlanco(entrada));
	}

}
