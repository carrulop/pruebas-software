package acme;

  import org.junit.jupiter.api.extension.ParameterContext;
  import org.junit.jupiter.params.aggregator.*;

  public class PersonaAggregator implements ArgumentsAggregator {

    @Override
    public Object aggregateArguments(ArgumentsAccessor accessor, 
                                     ParameterContext context)
	throws ArgumentsAggregationException {
	String nombre = accessor.getString(1);
	String apellidos = accessor.getString(2);
	Persona persona = new Persona(nombre, apellidos);
	return persona;
    }
  }
