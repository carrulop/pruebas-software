package acme;

 import java.time.LocalDate;
 import org.junit.jupiter.api.extension.ParameterContext;
 import org.junit.jupiter.params.converter
   .ArgumentConversionException;
 import org.junit.jupiter.params.converter.ArgumentConverter;

 public class DateConverter implements ArgumentConverter {

   @Override
   public Object convert(Object source, ParameterContext context) 
     throws ArgumentConversionException {
	if (!(source instanceof String)) {  // (1)
		throw new IllegalArgumentException(
             "El argumento debería ser un String: " + source);
	}
	try {
		String[] partes = ((String) source).split("/"); //(2)
		int anyo = Integer.parseInt(partes[2]);
		int mes = Integer.parseInt(partes[1]);
		int dia = Integer.parseInt(partes[0]);
			
		return LocalDate.of(anyo, mes, dia); //(3)
	} catch (Exception e) { //(4)
		throw new IllegalArgumentException(
"Error al convertir", e);
	}		
   }
 }
