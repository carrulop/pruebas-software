package acme;

import static org.junit.jupiter.api.Assertions.*;

import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.AggregateWith;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;

public class PersonaTest {

	@ParameterizedTest
	@MethodSource("generarDatosPersonas")
	void testDeberiaRetornarDatosPersona(Persona entrada, String resultadoEsperado) {
		assertEquals(resultadoEsperado, entrada.obtenerNombreCompleto());
	}

	private static Stream<Arguments> generarDatosPersonas() {
		return Stream.of(Arguments.of(new Persona("Arlen", "Mongalier"), "Arlen Mongalier"),
				Arguments.of(new Persona("Carlos", null), "Carlos"));
	}

	@ParameterizedTest
	@CsvSource({ "Arlen Mongalier,Arlen,Mongalier", "Juan,Juan," })
	void testObtenerNombreCompleto(String resultadoEsperado, String nombre, String apellidos) {
		Persona persona = new Persona(nombre, apellidos);
		assertEquals(resultadoEsperado, persona.obtenerNombreCompleto());
	}

	@ParameterizedTest
	@CsvSource({ "Arlen Mongalier,Arlen,Mongalier", "Juan,Juan," })
	void testObtenerNombreCompleto(ArgumentsAccessor argumentAccessor) {
		String nombre = argumentAccessor.getString(1);
		String apellidos = argumentAccessor.getString(2);
		String resultadoEsperado = argumentAccessor.getString(0);
		Persona persona = new Persona(nombre, apellidos);
		assertEquals(resultadoEsperado, persona.obtenerNombreCompleto());
	}

	@ParameterizedTest
	@CsvSource({ "Arlen Mongalier,Arlen,Mongalier", "Juan,Juan," })
	void testObtenerNombreCompleto(String resultadoEsperado, @AggregateWith(PersonaAggregator.class) Persona persona) {
		assertEquals(resultadoEsperado, persona.obtenerNombreCompleto());
	}

}
