package acme;

  import java.lang.reflect.Field;
  import java.util.stream.Stream;
  import org.junit.jupiter.api.extension.ExtensionContext;
  import org.junit.jupiter.params.provider.Arguments;
  import org.junit.jupiter.params.provider.ArgumentsProvider;
  import org.junit.jupiter.params.support.AnnotationConsumer;

  public class VariableArgumentsProvider implements 
       ArgumentsProvider, AnnotationConsumer<VariableSource> {

    private String nombreVariable; // (1)
	
    @Override
    public void accept(VariableSource t) { // (2)
    	 nombreVariable = t.value();
    }

    @Override
    public Stream<? extends Arguments> provideArguments( 
           ExtensionContext contexto) throws Exception { //(3)
	return contexto.getTestClass()
			.map(this::getField)
			.map(this::getValue)
			.orElseThrow(
                     () -> new IllegalArgumentException(
                            "Error al cargar los argumentos de " 
                          + "la prueba"));
    }
	
    private Field getField(Class<?> clase) { // (4)
	try {
		return clase.getDeclaredField(nombreVariable);
	} catch (Exception e) {
		return null;
	}
    }
	
    private Stream<Arguments> getValue(Field field) { // (5)
	Object value = null;
	try {
		value = field.get(null);
	} catch (Exception ignorado) {}
	
	return value == null ? null : (Stream<Arguments>) value;
    }
  }
