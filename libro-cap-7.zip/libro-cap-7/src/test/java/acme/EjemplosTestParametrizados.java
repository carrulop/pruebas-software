package acme;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.time.Month;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.converter.ConvertWith;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EnumSource;

public class EjemplosTestParametrizados {

	@ParameterizedTest(name = "{0} deberia estar entre el 1 y el 12")
	@EnumSource(Month.class)
	void testMesesDelAnyoDeberianIrDel1Al12(Month mes) {
		int numeroMes = mes.getValue();
		assertTrue(numeroMes > 0 && numeroMes <= 12);
	}

	@ParameterizedTest(name = "{0} debería tener 30 dias")
	@EnumSource(value = Month.class, names = { "APRIL", "JUNE", "SEPTEMBER", "NOVEMBER" })
	void testMesesDelAnyoDeberianTener30Dias(Month mes) {
		int diasMes = mes.length(false);
		assertEquals(30, diasMes);
	}

	@ParameterizedTest(name = "{0} debería tener 31 dias")
	@EnumSource(value = Month.class, names = { "FEBRUARY", "APRIL", "JUNE", "SEPTEMBER",
			"NOVEMBER" }, mode = EnumSource.Mode.EXCLUDE)
	void testMesesDelAnyoDeberianTener31Dias(Month mes) {
		int diasMes = mes.length(false);
		assertEquals(31, diasMes);
	}
	
	  @ParameterizedTest(name ="{0} debería acabar en BER")
	  @EnumSource(value = Month.class, names = {".+BER"}, 
	              mode = EnumSource.Mode.MATCH_ALL)
	  void testMesesDelAnyoTerminanEnBre(Month mes) {
		int diasMes = mes.length(false);
		assertTrue(diasMes > 0);
	  }

	  @ParameterizedTest(name ="{0} debería tener 30 dias")
	  @CsvSource({"APRIL", "JUNE", "SEPTEMBER", "NOVEMBER"})
	  void testMesesDelAnyoDeberianTener30DiasConCsvSource(Month mes) {
		int diasMes = mes.length(false);
		assertEquals(30, diasMes);
	  }
	  
	  @ParameterizedTest
	  @CsvSource({"01/12/2020,2020", "14/07/2024,2024"})
	  void testGetYearFuncionaComoSeEspera(
	       @ConvertWith(DateConverter.class) LocalDate fecha, 
	        int expectedYear) {
		assertEquals(expectedYear, fecha.getYear());
	  }



}
