package acme;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

public class CalculadoraTest {

	@Test
	void verificarEsImpar_1_RetornaTrue() {
		Calculadora calculadora = new Calculadora();
		assertTrue(calculadora.esImpar(1));
	}

	@Test
	void verificarEsImpar_3_RetornaTrue() {
		Calculadora calculadora = new Calculadora();
		assertTrue(calculadora.esImpar(3));
	}

	@Test
	void verificarEsImpar_Menos5_RetornaTrue() {
		Calculadora calculadora = new Calculadora();
		assertTrue(calculadora.esImpar(-5));
	}

	@ParameterizedTest(name = "Test {index}: El valor {0} debería " + "ser impar")
	@ValueSource(ints = { 1, 3, -5 })
	void verificarEsImparRetornaTrue(Integer valor) {
		Calculadora calculadora = new Calculadora();
		assertTrue(calculadora.esImpar(valor));
	}

}
