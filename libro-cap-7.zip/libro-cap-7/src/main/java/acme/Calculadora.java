package acme;

public class Calculadora {

	public int sumar(int a, int b) {
		return a + b;
	}

	public int dividir(int a, int b) {
		return a / b;
	}

	public boolean esImpar(int valor) {
		return valor % 2 != 0;
	}

}
