package acme;

public class Cadenas {
	public boolean esBlanco(String cadena) {
		return cadena == null || cadena.isBlank();
	}

	public String pasarMayusculas(String cadena) {
		if (cadena == null) {
			return null;
		}
		return cadena.toUpperCase();
	}

}
