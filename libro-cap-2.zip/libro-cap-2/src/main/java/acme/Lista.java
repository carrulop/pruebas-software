package acme;

import java.util.ArrayList;
import java.util.List;

public class Lista {

    protected List<String> elementos = new ArrayList<>();
	
    public void insertarElemento(String elemento) {
		elementos.add(elemento);
	}
	
	public String obtenerElemento(int indice) {
		if (esIndiceInvalido(indice)) {
			return null;
		}
		return elementos.get(indice);
	}
	
	public boolean eliminarElemento(int indice) {
		if (esIndiceInvalido(indice)) {
			return false;
		}
		elementos.remove(indice);
		return true;
	}

	private boolean esIndiceInvalido(int indice) {
		return indice < 0 || indice >= elementos.size();
	}

  }
