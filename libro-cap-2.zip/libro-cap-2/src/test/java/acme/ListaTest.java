package acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class ListaTest {
		
	@Test
	void testDeberiaInsertarUnElemento() {
           Lista lista = new Lista();
		lista.insertarElemento("Arlen");
		
		assertEquals(1, lista.elementos.size());
		assertEquals("Arlen", lista.elementos.get(0));
	}
	
	@Test
	void testDeberiaObtenerElemento() {
		Lista lista = new Lista();
		lista.insertarElemento("Arlen");
		String resultado = lista.obtenerElemento(0);
		assertEquals("Arlen", resultado);
	}
	
	@Test
	void testEliminarElementoValido() {
		Lista lista = new Lista();
		lista.insertarElemento("Arlen");
		boolean resultado = lista.eliminarElemento(0);
		assertTrue(resultado);
		assertEquals(0, lista.elementos.size());
	}

	
	@Test
	void testObtenerElementoDeberiaRetornarNullSiNoExiste() {
		Lista lista = new Lista();
		String resultado = lista.obtenerElemento(0);
		assertNull(resultado);
	}

	@Test
	void testEliminarElementoNoValidoDebeRetornarFalse() {
		Lista lista = new Lista();
		lista.insertarElemento("Arlen");
		boolean resultado = lista.eliminarElemento(2);
		assertFalse(resultado);
		assertEquals(1, lista.elementos.size());
	}

  }
