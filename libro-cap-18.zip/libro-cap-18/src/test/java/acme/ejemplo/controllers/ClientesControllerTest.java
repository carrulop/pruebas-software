package acme.ejemplo.controllers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import acme.ejemplo.dtos.ClienteDto;
import acme.ejemplo.services.ClientesService;

@ExtendWith(MockitoExtension.class) // (1)
public class ClientesControllerTest {

	@Mock
	private ClientesService clienteServiceMock; // (2)

	@InjectMocks
	private ClientesController controller; // (3)

	@Test
	void testObtenerTodosLosClientes() throws Exception {
		// Prepara el mock para la prueba (4)
		when(clienteServiceMock.recuperarTodos()).thenReturn(
				List.of(new ClienteDto(1, "Carlos", "951223888"), new ClienteDto(2, "Lorena", "950111888")));

		// Invocamos el método bajo prueba (5)
		List<ClienteDto> resultado = controller.buscarTodos();

		// Verificamos el resultado (6)
		assertNotNull(resultado);
		assertEquals(2, resultado.size());
		assertEquals("Carlos", resultado.get(0).getNombre());
		assertEquals("951223888", resultado.get(0).getTelefono());
		assertEquals(1, resultado.get(0).getId());

		verify(clienteServiceMock, times(1)).recuperarTodos();
		verifyNoMoreInteractions(clienteServiceMock);
	}
}
