package acme.ejemplo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.mock.env.MockEnvironment;

import acme.ejemplo.services.EjemploService;

public class EjemploServiceTest {

  private final static String NOMBRE = "Arlen";
	
  @Test
  void testObtenerSaludo() {
	// Configuramos el environment (1)
	MockEnvironment environmentMock = new MockEnvironment();
	environmentMock.setProperty("mensaje", NOMBRE);

	EjemploService service = new EjemploService(
                                    environmentMock); // (2)
	String resultado = service.obtenerSaludo();
				
	assertEquals("Hola Arlen", resultado); // (3)
  }
}
