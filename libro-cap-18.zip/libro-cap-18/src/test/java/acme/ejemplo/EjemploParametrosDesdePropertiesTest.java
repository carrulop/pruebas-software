package acme.ejemplo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import acme.ejemplo.services.EjemploService;

@SpringBootTest
@TestPropertySource(properties = {"mensaje=Madeleine"})
public class EjemploParametrosDesdePropertiesTest {
  @Autowired
  private EjemploService service;
 
  @Test
  void testObtenerSaludo() {

	String resultado = service.obtenerSaludo();
				
	assertEquals("Hola Madeleine", resultado);
  }
}
