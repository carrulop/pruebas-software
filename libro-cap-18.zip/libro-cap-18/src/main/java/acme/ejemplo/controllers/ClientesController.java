package acme.ejemplo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import acme.ejemplo.dtos.ClienteDto;
import acme.ejemplo.services.ClientesService;

@RestController
@RequestMapping("/clientes")
public class ClientesController {
	
	private final ClientesService service;
	
	@Autowired
	public ClientesController(ClientesService clientesService) {
		this.service = clientesService;
	}
	
	@GetMapping("/")
	public List<ClienteDto> buscarTodos() {	
		return service.recuperarTodos();
	}
}
