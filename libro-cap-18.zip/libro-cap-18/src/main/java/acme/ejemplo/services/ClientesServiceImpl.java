package acme.ejemplo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import acme.ejemplo.dtos.ClienteDto;

@Service
public class ClientesServiceImpl implements ClientesService {

	@Override
	public List<ClienteDto> recuperarTodos() {
		return null;
	}

	@Override
	public Optional<ClienteDto> buscarCliente(Integer id) {
		return Optional.empty();
	}

	@Override
	public ClienteDto nuevoCliente(ClienteDto cliente) {
		return null;
	}

	@Override
	public boolean eliminarCliente(Integer id) {
		return false;
	}
}
