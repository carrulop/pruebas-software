 package acme.ejemplo.services;

  import org.springframework.beans.factory.annotation.Autowired;
  import org.springframework.core.env.Environment;
  import org.springframework.stereotype.Service;

  @Service
  public class EjemploService {

	private Environment environment;
	
	@Autowired
	public EjemploService(Environment environment) {
		this.environment = environment;
	}
	
	public String obtenerSaludo() {
		return "Hola " + environment.getProperty("mensaje");
	}
  }
