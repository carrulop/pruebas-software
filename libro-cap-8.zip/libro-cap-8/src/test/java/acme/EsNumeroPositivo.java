package acme;

import org.hamcrest.Description;
import org.hamcrest.TypeSafeMatcher;

public class EsNumeroPositivo 
   extends TypeSafeMatcher<Integer> { // (1)
  @Override
  public void describeTo(Description description) { // (2)
  	description.appendText("Debería ser un número positivo");
  }

  @Override
  protected boolean matchesSafely(Integer item) { // (3)
	if (item > 0) {
		return true;
	}
	return false;
  }
	
  public static EsNumeroPositivo esNumeroPositivo() { // (4)
	return new EsNumeroPositivo();
  }
}
