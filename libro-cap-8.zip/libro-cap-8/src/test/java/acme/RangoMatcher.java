package acme;

import org.hamcrest.Description;
import org.hamcrest.TypeSafeMatcher;

public class RangoMatcher 
  extends TypeSafeMatcher<Integer> { // (1)

  private Integer limiteInferior; // (2)
	
  private Integer limiteSuperior;
	
  @Override
  public void describeTo(Description description) { // (3)
	description.appendText(
         String.format("Debería estar entre %d y %d",
                       limiteInferior, limiteSuperior));
	}

  @Override
  protected boolean matchesSafely(Integer item) { // (4)
	if (limiteInferior <= item && limiteSuperior >= item) {
		return true;
}
	return false;
  }
	
  public RangoMatcher(Integer valorInferior, 
                      Integer valorSuperior) { // (5)
	this.limiteInferior = valorInferior;
	this.limiteSuperior = valorSuperior;
  }
	
  public static RangoMatcher estaEntreRango( // (6)
        Integer valorInferior, Integer valorSuperior) {
	return new RangoMatcher(valorInferior, valorSuperior);
  }
}
