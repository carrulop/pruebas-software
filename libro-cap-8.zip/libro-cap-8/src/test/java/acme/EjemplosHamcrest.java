package acme;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

public class EjemplosHamcrest {

	@Test
	void pruebaEjemploMatchers() {
		assertThat("Cadena", is("Cadena"));
		assertThat("Cadena", equalTo("Cadena"));
		assertThat("Cadena", is(equalTo("Cadena")));
	}

	@Test
	void testIsEqualTo() {
		Persona actual = new Persona("Arlen", "Mongalier");
		Persona esperada = new Persona("Arlen", "Mongalier");
		assertThat(actual, is(esperada));
		assertThat(actual, equalTo(esperada));

	}

	@Test
	void testSameInstance() {
		Persona persona1 = new Persona("Arlen", "Mongalier");
		Persona persona2 = new Persona("Arlen", "Mongalier");
		Persona persona3 = persona1;
		assertThat(persona1, sameInstance(persona3)); // Pasará
		assertThat(persona1, not(sameInstance(persona2))); // Pasará
		assertThat(persona1, sameInstance(persona2)); // Fallará
	}

	@Test
	void testInstanceOf() {
		assertThat("Fulanito", instanceOf(String.class));
		assertThat("Menganito", isA(String.class));
		assertThat("Menganito", is(instanceOf(String.class)));
		assertThat("Menganito", is(not(instanceOf(Integer.class))));
		assertThat(new ArrayList(), isA(java.util.List.class));
		assertThat("Cadena", any(String.class));
		assertThat("Cadena", isA(Integer.class)); // No pasa
	}

	@Test
	void testHasProperty() {
		Persona persona = new Persona("Arlen", "Mongalier");
		assertThat(persona, hasProperty("nombre"));
		assertThat(persona, not(hasProperty("edad")));
		assertThat(persona, hasProperty("nombre", is("Arlen")));
	}

	@Test
	void testSamePropertyValuesAs() {
		Persona persona = new Persona("Arlen", "Mongalier");
		Persona expected = new Persona("Arlen", "Mongalier");
		Persona expected2 = new Persona("Arlen", "Garcia");
		assertThat(persona, samePropertyValuesAs(expected));
		assertThat(persona, not(samePropertyValuesAs(expected2)));
		assertThat(persona, samePropertyValuesAs(expected2, "apellidos"));
	}

	@Test
	void testNullValue() {
		assertThat("Fulanito", notNullValue());
		assertThat(null, nullValue());
		assertThat("Menganito", is(notNullValue()));

	}

	@Test
	void ejemploNot() {
		assertThat("Hola", not(emptyString()));
	}
	
	@Test
	void ejemploAllOf() {
	    assertThat("Hola a Todos", 
	                allOf(startsWith("Hola"), 
	                      endsWith("Todos"), 
	                      containsString("a")));
	}
	
	  @Test
	  void ejemploAnyOf() {
	    assertThat("Hola a Todos", 
	               anyOf(emptyString(), 
	                     startsWith("Hola"), 
	                     endsWith("Adios")));
	  }
	  
	  @Test
	  void ejemploArrays() {
		  String[] colores = {"Verde", "Azul", "Amarillo"};
		  assertThat(colores, arrayWithSize(3));
		  assertThat(colores, arrayWithSize(greaterThan(2)));
		  assertThat(colores, not(emptyArray()));
		  assertThat(colores, hasItemInArray("Azul"));
		  assertThat(colores, hasItemInArray(not(is("Azul"))));
		  assertThat(colores, not(hasItemInArray("Rojo")));
		  assertThat(colores, arrayContainingInAnyOrder("Azul",
                  "Amarillo", "Verde"));
		  assertThat(colores, not(arrayContainingInAnyOrder("Azul", "Amarillo")));
		  assertThat(colores, arrayContainingInAnyOrder(is("Azul"), is("Verde"), is("Amarillo")));
		  assertThat(colores, arrayContaining("Verde", "Azul", "Amarillo"));
		  assertThat(colores, not(arrayContaining("Azul", "Verde", "Amarillo")));

	  }

	  @Test
	  void ejemplosColecciones() {
		  Collection<String> colores = Arrays.asList("Verde", "Azul",  
                  "Amarillo");
		  assertThat(colores, hasSize(3));
		  assertThat(colores, hasSize(greaterThan(2)));
		  assertThat(colores, not(empty()));
		  assertThat(colores, hasItem("Azul"));
		  assertThat(colores, hasItem(not(is("Azul"))));
		  assertThat(colores, not(hasItem("Rojo")));

		  assertThat(colores, containsInAnyOrder("Azul",
                  "Amarillo", "Verde"));
		  assertThat(colores, not(containsInAnyOrder("Azul", 
                  "Amarillo")));
		  assertThat(colores, containsInAnyOrder(is("Azul"),
				  is("Verde"), is("Amarillo")));
		  assertThat(colores, contains("Verde", "Azul", "Amarillo"));
		  assertThat(colores, not(contains("Azul", "Verde", 
                     "Amarillo")));

		  List<Integer> numeros = Arrays.asList(2, 4, 6, 8, 12);
		  assertThat(numeros, everyItem(greaterThan(0)));
	  }
	  
	  @Test
	  void ejemploMapas() {
		  Map<String, Integer> mapColores = new HashMap<>();
		  mapColores.put("Verde", 2);
		  mapColores.put("Azul", 50); 
		  assertThat(mapColores, aMapWithSize(2));
		  assertThat(mapColores, aMapWithSize(greaterThan(1)));
		  
		  Map<String, Integer> mapColoresVacio = new HashMap<>();
		  assertThat(mapColoresVacio, anEmptyMap());

		  assertThat(mapColores, hasKey("Azul"));
		  assertThat(mapColores, hasKey(not(is("Azul"))));
		  assertThat(mapColores, not(hasKey("Rojo")));

		  assertThat(mapColores, hasValue(50));
		  assertThat(mapColores, hasValue(greaterThan(25)));
		  assertThat(mapColores, not(hasValue(5)));

		  assertThat(mapColores, hasEntry("Azul", 50));
		  assertThat(mapColores, hasEntry(is("Azul"), greaterThan(25)));
		  assertThat(mapColores, not(hasEntry("Verde", 50)));

	  }
	  
	  @Test
	  void testMatcherPersonalizado() {
		  assertThat(10, EsNumeroPositivo.esNumeroPositivo());
		  assertThat(10, RangoMatcher.estaEntreRango(1, 10));
		  assertThat(-5, not(EsNumeroPositivo.esNumeroPositivo()));
		  assertThat(8, MatcherPersonalizado.matchesInteger(lessThan(10)));
	  }
}
