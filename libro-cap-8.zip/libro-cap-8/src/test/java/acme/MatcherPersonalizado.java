package acme;

import org.hamcrest.*;

public class MatcherPersonalizado 
    extends TypeSafeMatcher<Integer> { // (1)
	
  Matcher<Integer> valorEsperado;  // (2)

  @Override
  public void describeTo(Description description) { // (3)
	description.appendDescriptionOf(valorEsperado);
  }

  @Override
  protected boolean matchesSafely(Integer item) { // (4)
	return valorEsperado.matches(item);
  }

  public MatcherPersonalizado(Matcher<Integer> valorEsperado) {
	this.valorEsperado = valorEsperado; // (5)
  }

  public static MatcherPersonalizado matchesInteger( // (6)
                 Matcher<Integer> matcher) {
	return new MatcherPersonalizado(matcher);
  }
}
