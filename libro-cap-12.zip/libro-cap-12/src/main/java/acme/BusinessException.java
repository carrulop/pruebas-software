package acme;

public class BusinessException extends Exception {

	public BusinessException(String mensaje) {
		super(mensaje);
	}
}
