package acme.productos;

import java.io.IOException;
import java.util.List;

public interface ImpuestosProxy {

	List<ElementoIva> obtenerElementosIva() throws IOException;

}
