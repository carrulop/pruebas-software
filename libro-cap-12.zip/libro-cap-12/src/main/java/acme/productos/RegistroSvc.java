package acme.productos;
public class RegistroSvc {

  private ServicioEmail servicioEmail;
  
  private RegistroRepository dao;
      
  public void setServicioEmail(ServicioEmail serv) {
    this.servicioEmail = serv;
  }

  public void guardarRegistro(Registro registro) {
        
    // Hacer algo con el registro
	  this.dao.guardar(registro);

	  // Enviar un correo electrónico
    this.servicioEmail.enviar(
       "El registro se realizó correctamente");
  }
}
