package acme.productos;

public interface ServicioEmail {

	void enviar(String string);

}
