package acme.productos;

public interface RegistroRepository {

	void guardar(Registro registro);

}
