package acme.productos;

public enum TipoIva {

	NORMAL, REDUCIDO, SUPER_REDUCIDO;
}
