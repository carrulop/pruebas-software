package acme.productos;

public class Registro {

}
