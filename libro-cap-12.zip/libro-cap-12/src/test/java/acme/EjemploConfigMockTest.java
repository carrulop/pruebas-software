package acme;

import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.withSettings;

import java.time.Instant;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

//@MockitoSettings(strictness = Strictness.STRICT_STUBS)
//@MockitoSettings(strictness = Strictness.WARN)
@MockitoSettings(strictness = Strictness.LENIENT)
@ExtendWith(MockitoExtension.class)
public class EjemploConfigMockTest {

	@Test
	void ejemploTestIneficiente() throws Exception {
		Date dateMock = Mockito.mock(Date.class);
		Mockito.when(dateMock.toInstant()).thenReturn(Instant.now());
	}

	@Mock(lenient=false)
    Date dateMock;
    @Test
	void ejemploTestIneficiente2() throws Exception {
      Mockito.when(dateMock.toInstant()).thenReturn(
                                        Instant.now());
	}
    
    @Test
	void ejemploTestIneficiente3() throws Exception {
      Date dateMock = Mockito.mock(Date.class, withSettings().strictness(Strictness.WARN));
      Mockito.when(dateMock.toInstant()).thenReturn(
                                        Instant.now());
      
	}
    
    

}
