package acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;

public class EjemploMocksTest {

	@Test
	void ejemploMockear() {
		Iterator<String> iterator = mock(Iterator.class);
		when(iterator.next()).thenReturn("Hola").thenReturn("Mundo");
		System.out.println(iterator.next() + " " + iterator.next());
	}

	@Test
	void testMockitoRetornaValorDependiendoDatoDeEntrada() {
		Comparable<String> c = mock(Comparable.class); // (1)
		when(c.compareTo("Mockito")).thenReturn(1); // (2)
		when(c.compareTo("Eclipse")).thenReturn(2); // (3)

		System.out.println(c.compareTo("Eclipse")); // Escribe 2
		System.out.println(c.compareTo("Mockito")); // Escribe 1
	}

	@Test
	void testEjemploConArgumentMatcher() {
		Comparable<Integer> c = mock(Comparable.class);
		when(c.compareTo(anyInt())).thenReturn(-1);

		assertEquals(-1, c.compareTo(3));
		assertEquals(-1, c.compareTo(9));
	}

	@Test
	public void testRetornarValorDependiendoTipo() {

		Comparable c = mock(Comparable.class);

		when(c.compareTo(ArgumentMatchers.isA(String.class))).thenReturn(1);

		// Asertar
		String str = "Test";
		assertEquals(1, c.compareTo(str));
		assertEquals(0, c.compareTo(5));
	}

	@Test
	public void testRetornaNadaSobreMetodo() {
		Date date = mock(Date.class);
		doNothing().when(date).setDate(0);

		// La siguiente llamada no hará nada
		date.setDate(0);
	}

	@Test
	void testEjemploLlamadaMetodoReal() {
		ArrayList<String> listaMockeada = mock(ArrayList.class);
		when(listaMockeada.size()).thenReturn(2).thenCallRealMethod();
		System.out.println(listaMockeada.size()); // Escribe: 2
		System.out.println(listaMockeada.size()); // Escribe: 0

		List<String> listaMockeada2 = mock(List.class);
		when(listaMockeada2.size()).thenCallRealMethod(); // Esto fallará, ya que List no es
															// una clase concreta.
	}

	@Test
	public void testParaIOException() throws IOException {

		// Crear y configurar un mock
		OutputStream mockStream = mock(OutputStream.class);
		Mockito.doThrow(new IOException("Error controlado")).when(mockStream).close();

		// Usar el mock
		OutputStreamWriter streamWriter = new OutputStreamWriter(mockStream);

		IOException exception = Assertions.assertThrows(IOException.class, () -> streamWriter.close());
		assertNotNull(exception);
		assertEquals("Error controlado", exception.getMessage());
	}

}
