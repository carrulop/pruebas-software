package acme.productos;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class ProductosServiceTest {
	
  private ProductosService productoService; // (1)
  private ImpuestosProxy impuestosProxyMocked; // (2)
	
  @BeforeEach
  public void setup() {
	impuestosProxyMocked = Mockito.mock(
               ImpuestosProxy.class);  // (3)
	productoService = new ProductosService(
                impuestosProxyMocked);  // (4)
  }
	
  @Test
  void testCalcularPrecioTotal1() { //(5)
	double resultadoReal = assertDoesNotThrow(
         () -> productoService.calculaPrecioTotal(
                TipoIva.NORMAL, 1000.0, 0.25));
	double resultadoEsperado = 907.5;
	assertEquals(resultadoEsperado, resultadoReal, 0.01);
  }
}