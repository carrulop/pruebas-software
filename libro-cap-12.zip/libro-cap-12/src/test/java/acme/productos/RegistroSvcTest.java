package acme.productos;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class RegistroSvcTest {

	 @Test
	    public void testGuardarRegistro() {
	        ServicioEmail serv = mock(ServicioEmail.class);
	        doNothing().when(serv).enviar(Mockito.any(String.class));
	        
		   RegistroSvc tester = new RegistroSvc();
	        tester.setServicioEmail(serv);
		   tester.guardarRegistro(new Registro());

		   //Asertar algo sobre la ejecución

	    }


}
