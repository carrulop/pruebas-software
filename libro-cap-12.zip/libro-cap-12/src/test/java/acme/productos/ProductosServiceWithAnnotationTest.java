package acme.productos;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class) // (1)
public class ProductosServiceWithAnnotationTest {
	
	@Mock
	private ImpuestosProxy impuestosProxyMocked; // (2)

	@InjectMocks
	private ProductosService productoService; // (3)
		
	@Test
	void testCalcularPrecioTotal() { // (4)
     double resultadoReal = assertDoesNotThrow(
         () -> productoService.calculaPrecioTotal(
                TipoIva.NORMAL, 1000.0, 0.25));
	  double resultadoEsperado = 907.5;
	  assertEquals(resultadoEsperado, resultadoReal, 0.01);
	}
}
