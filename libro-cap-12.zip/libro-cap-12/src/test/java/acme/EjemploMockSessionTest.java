package acme;
import java.time.Instant;
import java.util.Date;
import org.junit.jupiter.api.*;
import org.mockito.Mockito;
import org.mockito.MockitoSession;
import org.mockito.quality.Strictness;

public class EjemploMockSessionTest {
	MockitoSession mockito; //(1)
	
	@BeforeEach
	void setup() {
		mockito = Mockito.mockitoSession()
                            .strictness(Strictness.WARN)
                            .startMocking();  // (2)
	}
	@Test
	void testIneficiente() {
		Date dateMock = Mockito.mock(Date.class); //(3)
  	     Mockito.when(dateMock.toInstant())
                               .thenReturn(Instant.now());
	}
	@AfterEach
	void tearDown() {
		mockito.finishMocking(); // (4)
	}
}
