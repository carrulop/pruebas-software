package acme.ejemplo.services;

import java.util.List;
import java.util.Optional;
import acme.ejemplo.dtos.ClienteDto;

public interface ClientesService {

	List<ClienteDto> recuperarTodos();
	
	Optional<ClienteDto> buscarCliente(Integer id);
	
	ClienteDto nuevoCliente(ClienteDto cliente);
	
	boolean eliminarCliente(Integer id);
	
}
