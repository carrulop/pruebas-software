package acme.ejemplo.exceptions;

public class ClienteNoEncontradoException extends AplicacionException {

	public ClienteNoEncontradoException(String mensaje) {
		super(mensaje);
	}

}
