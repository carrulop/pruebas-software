package acme.ejemplo.controllers;

import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest
                                .WebEnvironment;
import org.springframework.boot.web.servlet.context
                     .ServletWebServerApplicationContext;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import acme.ejemplo.dtos.ClienteDto;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class ClientesControllerRealIntegrationTest { // (1)

	private RestTemplate restTemplate; // (2)

	@Autowired  // (3)
	private ServletWebServerApplicationContext webServerAppCtxt;
	
	private int serverPort; // (4)

	@BeforeEach
	public void setup() { // (5)
        serverPort = webServerAppCtxt.getWebServer()
  .getPort();
          restTemplate = new RestTemplate();
	}
	
	@Test
	void testRecuperarClientes() {
 	  // (6) Se invoca la url del endpoint a probar: /clientes/
     String url = "http://localhost:" + serverPort 
                                      + "/clientes/";
	  ResponseEntity<ClienteDto[]> result = restTemplate
                      .getForEntity(url, ClienteDto[].class);

	  // (7) Se valida la respuesta
  	  List<ClienteDto> lista = Arrays.asList(result.getBody());
  
  assertEquals(2, lista.size());
  assertEquals("Arlen", lista.get(0).getNombre());
  assertEquals("Yvonne", lista.get(1).getNombre());
	}
}
