  package acme.ejemplo.controllers;

  import static org.junit.jupiter.api.Assertions.*;
  import org.springframework.test.web.servlet.result.*;
  import static org.mockito.Mockito.*;
  import java.util.List;
import java.util.Optional;

import org.hamcrest.Matchers;
  import org.junit.jupiter.api.*;
  import org.junit.jupiter.api.extension.ExtendWith;
  import org.mockito.*;
  import org.mockito.junit.jupiter.MockitoExtension;
  import org.springframework.http.MediaType;
  import org.springframework.test.web.servlet.*;
  import org.springframework.test.web.servlet.request.*;
  import static org.springframework.test.web.servlet.result
            .MockMvcResultMatchers.*;
  import org.springframework.test.web.servlet.setup
            .MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

import acme.ejemplo.dtos.ClienteDto;
  import acme.ejemplo.services.ClientesService;

  @ExtendWith(MockitoExtension.class) // (1)
  public class ClientesControllerIntegrationTest {

    @Mock  // (2)
    private ClientesService clienteServiceMock; 
	
    @InjectMocks  // (3)
    private ClientesController controller;

    private MockMvc mockMvc; // (4)

    private static ObjectMapper mapper = new ObjectMapper();
    private final static String NOMBRE = "Arlen";
    private final static String TELEFONO = "951222888";


    @BeforeEach
    public void setup() {
      RestErrorHandler restErrorHandler = new RestErrorHandler();
      this.mockMvc = MockMvcBuilders
              .standaloneSetup(controller)	// (5)
              .setControllerAdvice(restErrorHandler)
              .build();

    }

    @Test
    void testObtenerTodosLosClientes() throws Exception {	
       // Configuramos la prueba (6)
	  when(clienteServiceMock.recuperarTodos()).thenReturn(
            List.of(new ClienteDto(1, "Carlos", "951234888"), 
                    new ClienteDto(2, "Lorena", "950222888"),
                    new ClienteDto(3, "Mar", "957485666")));

	  //	Invocamos a la URL /clientes/    (7)
	  MvcResult result = mockMvc.perform(
         MockMvcRequestBuilders.get("/clientes/")
		.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$", Matchers.hasSize(3)))	   
		.andExpect(MockMvcResultMatchers.jsonPath(
		                      "$[0].nombre", Matchers.is("Carlos")))
		.andExpect(MockMvcResultMatchers.jsonPath(
		                      "$[0].id", Matchers.is(1)))					.andExpect(MockMvcResultMatchers.jsonPath(
		                    "$[0].telefono", Matchers.is("951234888")))
        .andReturn();
        assertEquals("application/json", 
		                  result.getResponse().getContentType());
        verify(clienteServiceMock, times(1)).recuperarTodos();//(8)
		verifyNoMoreInteractions(clienteServiceMock);
    }
    

  @Test
  void testBuscarCliente() throws Exception {
   // Se configura el objeto mock
	when(clienteServiceMock.buscarCliente(anyInt()))
			.thenReturn(Optional.of(
                  new ClienteDto(1, "Arlen", "951123488")));

	// Se ejecuta la petición HTTP GET /clientes/1
   mockMvc.perform(
      MockMvcRequestBuilders.get("/clientes/{id}", 1)
      .contentType(MediaType.APPLICATION_JSON))
      .andExpect(status().isOk())
	   .andExpect(jsonPath("$.nombre", Matchers.is("Arlen")))
	   .andExpect(jsonPath("$.id", Matchers.is(1)))
	   .andExpect(jsonPath("$.telefono", 
                          Matchers.is("951123488")));
  }

  @Test
  void testBuscaClienteCuandoNoExiste() throws Exception {
     // Se configura el objeto mock para que retorne vacío
  	when(clienteServiceMock.buscarCliente(anyInt()))
  			.thenReturn(Optional.empty()); // (2)
     // Se invoca la operación /clientes/1
  	mockMvc.perform(MockMvcRequestBuilders.get(
                       "/clientes/{id}", 1)
            .contentType(MediaType.APPLICATION_JSON))
  	.andExpect(status().isNotFound())   // (3)
  	.andExpect(jsonPath("$.codigo", Matchers.is("10")))
  	.andExpect(jsonPath("$.mensaje", Matchers.is(
                              "Recurso no encontrado")));
  }

  @Test
  void testNuevoCliente() throws Exception {
     // Configuramos el objeto mock para que retorne el cliente
  	when(clienteServiceMock.nuevoCliente(any()))
           .thenReturn(new ClienteDto(2, NOMBRE, TELEFONO));

  	// Preparamos los datos de entrada para el alta de cliente
  	ClienteDto cliente = new ClienteDto(null, NOMBRE, TELEFONO);
  	String json = mapper.writeValueAsString(cliente); 

  	mockMvc.perform(MockMvcRequestBuilders.post("/clientes/")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .content(json))    
  	   .andExpect(status().isCreated()) 
  	   .andExpect(jsonPath("$.id", Matchers.is(2)))
  	   .andExpect(jsonPath("$.nombre", Matchers.is(NOMBRE)))
  	   .andExpect(jsonPath("$.telefono",
                            Matchers.is(TELEFONO)));
  	
    }

  @Test
  void testNuevoClienteFallaSiNombreVacio() throws Exception {
  	ClienteDto cliente = new ClienteDto(null, "", "951222888");
  	String json = mapper.writeValueAsString(cliente);
  	mockMvc.perform(MockMvcRequestBuilders.post("/clientes/")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON).content(json))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.errors", Matchers.hasSize(1)))
            .andExpect(jsonPath("$.errors[0]", 
                      Matchers.is("Nombre es obligatorio")));		
  }
  
  @Test
  void testSaludoConParametro() throws Exception {
	mockMvc.perform(MockMvcRequestBuilders.get("/clientes/saludo")
             .param("nombre", "Arlen"))
             .andExpect(status().isOk())
             .andExpect(MockMvcResultMatchers.content().string(
                                  "Hola Arlen"));
  }


}
