package acme.ejemplo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure  
          .SpringBootApplication;

@SpringBootApplication
public class EjemploKafkaApplication {

	public static void main(String[] args) {
	   SpringApplication.run(
                EjemploKafkaApplication.class, args);
	}
}
