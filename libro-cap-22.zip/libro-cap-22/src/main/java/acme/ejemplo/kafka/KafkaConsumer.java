package acme.ejemplo.kafka;

import java.util.concurrent.CountDownLatch;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component // (1)
public class KafkaConsumer {

  private static final Logger LOGGER = LoggerFactory.getLogger(
                                          KafkaConsumer.class);

  private CountDownLatch latch = new CountDownLatch(1); // (2)
  private String payload;

  @KafkaListener(topics = "${test.topic}")   // (3)
  public void recibir(ConsumerRecord<?, ?> consumerRecord) {
        LOGGER.info("recibido payload='{}'", 
                     consumerRecord.toString());
        payload = consumerRecord.toString(); // (4)
        latch.countDown();  // (5)
  }

  public void resetLatch() {  // (6)
    latch = new CountDownLatch(1);
  }

  public CountDownLatch getLatch() {
	 return latch;
  }

  public void setLatch(CountDownLatch latch) {
	 this.latch = latch;
  }

  public String getPayload() {
	 return payload;
  }

  public void setPayload(String payload) {
	 this.payload = payload;
  }
}
