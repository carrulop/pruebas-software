package acme.ejemplo.controllers;

import org.springframework.beans.factory.annotation.*;
import org.springframework.web.bind.annotation.*;
import acme.ejemplo.kafka.KafkaProducer;

@RestController // (1)
public class MensajeController {

	@Autowired  // (2)
	private KafkaProducer producer;
	
	@Value("${test.topic}")  // (3)
	private String testTopic;
	
	@GetMapping("/saludo")  // (4)
	public String saludar(@RequestParam(value = "nombre",
                       defaultValue = "") String nombre) {
      producer.enviar(testTopic, "Enviado mensaje a " 
                               + nombre);
      return "Hola " + nombre;
	}
}
