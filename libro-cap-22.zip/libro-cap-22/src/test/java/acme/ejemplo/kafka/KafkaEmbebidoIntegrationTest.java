package acme.ejemplo.kafka;

import static org.junit.jupiter.api.Assertions.assertTrue;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.test.annotation.DirtiesContext;

@SpringBootTest // (1)
@DirtiesContext // (2)
@EmbeddedKafka(partitions = 1, brokerProperties = { "listeners=PLAINTEXT://localhost:9092", "port=9092" }) //(3)
class KafkaEmbebidoIntegrationTest {

    @Autowired
    private KafkaConsumer consumer; // (4)

    @Autowired
    private KafkaProducer producer; // (5)

    @Value("${test.topic}") // (6)
    private String topic;

    @Test
    public void testMensajeRecibidoCuandoSeEnviaMensaje() 
      throws Exception {
        String data = "Enviando un mensaje a KafkaProducer";
        producer.enviar(topic, data); // (7)
        
		// Comprobar si se ha consumido el mensaje (8)
        boolean mensajeConsumido = consumer.getLatch()
                                      .await(10,
                                             TimeUnit.SECONDS);
        assertTrue(mensajeConsumido);
        String payLoad = consumer.getPayload();// (9)
        assertTrue(payLoad.contains(data));
    }
}
