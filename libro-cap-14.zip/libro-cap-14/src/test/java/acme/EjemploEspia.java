package acme;
  import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
  import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
import org.mockito.Mockito;

  public class EjemploEspia {

	private Persona personaEspiada;
	private Persona persona;
	private static final String NOMBRE = "Arlen";
	private static final String APELLIDOS = "Mongalier";
	private static final int EDAD = 35;
	
	@BeforeEach
	public void setup() {
		persona = new Persona(NOMBRE, APELLIDOS, EDAD);
		personaEspiada = Mockito.spy(persona);
	}
	
	@Test
	void verificarEfectoEspiaEnInstanciaReal() {
		personaEspiada.setEdad(20);
		assertNotEquals(persona.getEdad(),
                           personaEspiada.getEdad());
	}
	
	@Test
	void testDiferenciaObjetoMockYObjetoSpy() {
	     Persona personaMock = Mockito.mock(Persona.class);
	     Persona personaSpy = Mockito.spy(new Persona(NOMBRE, 
	                                      APELLIDOS, EDAD));
	     assertNull(personaMock.getNombreCompleto());

	     assertEquals(NOMBRE + " " + APELLIDOS,
	                  personaSpy.getNombreCompleto());
	}
	
	@Test
	void verificaDetallesPersona() {
	    assertEquals(NOMBRE + " " + APELLIDOS, 
	                 personaEspiada.getNombreCompleto()); //(1)

	    assertEquals(EDAD, personaEspiada.getEdad()); //(2)

	    InOrder inOrder = Mockito.inOrder(personaEspiada); //(3)

	    // Verificar que persona.getNombreCompleto() llama
	    // getNombre() y luego getApellidos()
	    inOrder.verify(personaEspiada).getNombre();
	    inOrder.verify(personaEspiada).getApellidos();

	    // Verificar que persona.getEdad() es llamado
	    verify(personaEspiada).getEdad(); //(4)

	    assertEquals(personaEspiada.getNombre(), NOMBRE); // (5)
	    assertEquals(personaEspiada.getApellidos(), APELLIDOS);

	    // Verificar que persona.getNombre()es llamado dos veces
	    verify(personaEspiada, Mockito.times(2)).getNombre();//(6)
	}

	@Test
	void entrenarEspiaNombrePersona() {
		final String YO_SOY = "Yo soy";
		final String EL_ESPIA = "el Espia";
		
		//Entrenar la persona para retornar YO_SOY cuando 
	   // se llama al método getNombre().
		when(personaEspiada.getNombre()).thenReturn(YO_SOY); //(1)

		assertEquals(YO_SOY + " " + APELLIDOS, 
	                personaEspiada.getNombreCompleto()); // (2)
		
		// Entrenar a la persona para retornar EL_ESPIA 
		//   cuando se invoca a getApellido()
		when(personaEspiada.getApellidos())
	                      .thenReturn(EL_ESPIA);//(3)

		assertEquals(YO_SOY + " " + EL_ESPIA, 
	                personaEspiada.getNombreCompleto());
	}
	
	@Test
	public void spyDireccionesUsandoWhenThenReturn() {
		when(personaEspiada.getDireccion(0)).thenReturn("ESPIA");
		assertEquals("ESPIA", personaEspiada.getDireccion(0));
	}

	@Test
	public void spyDireccionesUsandoDoWhen() {
		doReturn("ESPIA").when(personaEspiada).getDireccion(0);
		assertEquals("ESPIA", personaEspiada.getDireccion(0));
	}

	  @Test
	  void testEspiarClaseAnonima() {
			
		Animal perro = new Animal() {  // (1)
				@Override
				public String emitirSonido() {
					return "guau";
				}
		};

		Animal perroEspia = Mockito.spy(perro); // (2)
			
		assertEquals("guau", perroEspia.emitirSonido()); // (3)
		
	     Mockito.when(perroEspia.emitirSonido())
	       .thenReturn("miau");  // (4)
		assertEquals("miau", perroEspia.emitirSonido()); // (5)
	  }

	  @Test
	  void testMetodoEstatico() {
	    Persona personaEspiada = Mockito.spy(Persona.class);
	    doReturn(500).when(personaEspiada).metodoEstatico();
	    System.out.println(personaEspiada);
	  }


}
