package acme;

import java.util.ArrayList;
import java.util.List;

public class Persona {

    private String nombre;
    private String apellidos;
    private int edad;
    private List<String> direcciones;

    public static int metodoEstatico() {
  	  return 1000;
    }

   	public Persona(String nombre, String apellidos, int edad) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.edad = edad;
	}

	public String getNombre() {
		return nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public String getNombreCompleto() {
		return getNombre() + " " + getApellidos();
	}
	
    public String getDireccion(int indice) {
	return direcciones.get(indice);
    }

    public void addDireccion(String direccion1, 
                    String direccion2, String direccion3) {
	if (direcciones == null) {
		direcciones = new ArrayList<>(3);
	}
	direcciones.add(0, direccion1);
	direcciones.add(1, direccion2);
	direcciones.add(2, direccion3);
   }

}
