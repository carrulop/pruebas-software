package acme;
public interface Animal {
	String emitirSonido();	
}
