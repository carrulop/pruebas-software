package acme.reactivo.dao;
import org.springframework.data.r2dbc.repository  
          .R2dbcRepository;
import org.springframework.stereotype.Repository;
import acme.reactivo.model.ClienteEntity;
import reactor.core.publisher.Flux;

@Repository
public interface ClienteReactivoRepository 
         extends R2dbcRepository<ClienteEntity, Integer> {

	Flux<ClienteEntity> findByNombreContaining(String nombre);
}
