package acme.reactivo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
  import acme.reactivo.dtos.ClienteDto;
import acme.reactivo.service.ClienteReactivoService;
import reactor.core.publisher.*;

@RestController
@RequestMapping("/api")
public class ClienteReactivoController {
	
	@Autowired
	private ClienteReactivoService service;
	
	@GetMapping("/clientes")
	@ResponseStatus(HttpStatus.OK)
	public Flux<ClienteDto> recuperarTodosLosClientes() {
		return service.findAll();
	}
	
	@GetMapping("/clientes/{id}")
	@ResponseStatus(HttpStatus.OK)
	public Mono<ClienteDto> recuperarCliente(
                   @PathVariable("id") Integer id) {
		return service.findById(id);
	}

   @PostMapping("/clientes")
	@ResponseStatus(HttpStatus.CREATED)
	public Mono<ClienteDto> crearCliente(
                   @RequestBody ClienteDto cliente) {
      return service.save(new ClienteDto(null, 
              cliente.getNombre(), cliente.getTelefono()));
   }
	  
   @DeleteMapping("/clientes/{id}")
   @ResponseStatus(HttpStatus.NO_CONTENT)
   public Mono<Void> eliminarCliente(
          @PathVariable("id") int id) {
	    return service.deleteById(id);
   }
}
