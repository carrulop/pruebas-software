package acme.reactivo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import acme.reactivo.dao.ClienteReactivoRepository;
import acme.reactivo.dtos.ClienteDto;
import acme.reactivo.model.ClienteEntity;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class ClienteReactivoService {

	@Autowired
	ClienteReactivoRepository repository;

	public Flux<ClienteDto> findAll() {
		return repository.findAll().map(ClienteDto::new);
	}

	public Mono<ClienteDto> findById(Integer id) {
		return repository.findById(id).map(ClienteDto::new);
	}

	public Mono<ClienteDto> save(ClienteDto cliente) {
		ClienteEntity entity = new ClienteEntity();
		entity.setNombre(cliente.getNombre());
		entity.setTelefono(cliente.getTelefono());
		return repository.save(entity).map(ClienteDto::new);
	}

	public Mono<Void> deleteById(Integer id) {
		return repository.deleteById(id);
	}
}
