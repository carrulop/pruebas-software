package acme.reactivo.controller;

  import org.junit.jupiter.api.*;
  import org.springframework.beans.factory.annotation.Autowired;
  import org.springframework.boot.test.context.SpringBootTest;
  import org.springframework.boot.test.context.SpringBootTest 
            .WebEnvironment;
  import org.springframework.test.web.reactive.server  
            .WebTestClient;

  import acme.reactivo.dtos.ClienteDto;
  import reactor.core.publisher.Mono;

  @SpringBootTest(
          webEnvironment = WebEnvironment.RANDOM_PORT) //(1)
  public class ClientesReactivoControllerRealIntegrationTest {

	private static final String NOMBRE = "Arlen";
	private static final String TELEFONO = "951122888";

	@Autowired  // (2)
	private WebTestClient webTestClient;

	@Test
	void testNuevoCliente() {
         ClienteDto entrada = new ClienteDto(
                                 null, NOMBRE, TELEFONO);

         webTestClient.post()   // (3) Se envía la petición
               .uri("/api/clientes")
		    .body(Mono.just(entrada), ClienteDto.class)
		    .exchange()
              // (4) Se verifica la respuesta
		    .expectStatus().isCreated()
      	    .expectBody()
		  	   .jsonPath("$.id").isNumber()
	       	   .jsonPath("$.nombre").isEqualTo(NOMBRE)
                   .jsonPath("$.telefono").isEqualTo(TELEFONO);

	    // Se invoca a la URL GET /api/clientes (5)
	    webTestClient.get().uri("/api/clientes")
		  .exchange()
		  .expectStatus()
		  .isOk()
		   .expectBody()
                .jsonPath("$").isArray()
                .jsonPath("$.length()").isEqualTo(1)
                .jsonPath("$[0].nombre").isEqualTo(NOMBRE)
                .jsonPath("$[0].telefono").isEqualTo(TELEFONO);
	}
	
  }
