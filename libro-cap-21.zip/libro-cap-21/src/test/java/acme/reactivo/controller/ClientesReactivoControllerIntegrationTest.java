package acme.reactivo.controller;

  import static org.mockito.ArgumentMatchers.any;
  import static org.mockito.Mockito.when;
  import org.junit.jupiter.api.Test;
  import org.junit.runner.RunWith;
  import org.springframework.beans.factory.annotation.Autowired;
  import org.springframework.boot.test.autoconfigure.web 
            .reactive.WebFluxTest;
  import org.springframework.boot.test.mock.mockito.MockBean;
  import org.springframework.test.context.junit4.SpringRunner;
  import org.springframework.test.web.reactive.server  
            .WebTestClient;
  import acme.reactivo.dtos.ClienteDto;
  import acme.reactivo.service.ClienteReactivoService;
  import reactor.core.publisher.Mono;

  @RunWith(SpringRunner.class) // (1)
  @WebFluxTest(ClienteReactivoController.class) // (2)
  public class ClientesReactivoControllerIntegrationTest {

     private static final String NOMBRE = "Arlen";
     private static final String TELEFONO = "9512888";

	@Autowired  // (3)
	private WebTestClient webTestClient;
	@MockBean  // (4)
	private ClienteReactivoService serviceMock;

	@Test
	void testNuevoCliente() {
		// Configuramos serviceMock (5)
		Mono<ClienteDto> clienteMono = Mono.just(
                new ClienteDto(1, NOMBRE, TELEFONO));
		when(serviceMock.save(any())).thenReturn(clienteMono);

		ClienteDto entrada = new ClienteDto(
                                  null, NOMBRE, TELEFONO);

		// Se invoca la URL a probar (6)
		webTestClient.post()
                     .uri("/api/clientes")
	       	     .body(Mono.just(entrada), ClienteDto.class)
                     .exchange()
			// Se verifica la respuesta (7)
                     .expectStatus().isCreated()
	       	     .expectBody()
		       	     .jsonPath("$.id").isEqualTo(1)
	       	     .jsonPath("$.nombre").isEqualTo(NOMBRE)
                     .jsonPath("$.telefono").isEqualTo(TELEFONO);
	}
  }
