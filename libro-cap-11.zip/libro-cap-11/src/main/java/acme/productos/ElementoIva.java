package acme.productos;

public class ElementoIva {

	private String tipoIva;
	
	private double porcentaje;
	
	public ElementoIva(String tipoIva, double porcentaje) {
		super();
		this.tipoIva = tipoIva;
		this.porcentaje = porcentaje;
	}

	public String getTipoIva() {
		return tipoIva;
	}

	public void setTipoIva(String tipoIva) {
		this.tipoIva = tipoIva;
	}

	public double getPorcentaje() {
		return porcentaje;
	}

	public void setPorcentaje(double porcentaje) {
		this.porcentaje = porcentaje;
	}

	@Override
	public String toString() {
		return "ElementoIva [tipoIva=" + tipoIva + ", porcentaje=" + porcentaje + "]";
	}
	
}
