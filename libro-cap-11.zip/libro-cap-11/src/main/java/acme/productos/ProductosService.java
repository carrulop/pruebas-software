package acme.productos;

import java.io.IOException;
import java.util.List;

import acme.BusinessException;

public class ProductosService {

	private ImpuestosProxy impuestosProxy;
	public ProductosService(ImpuestosProxy impuestosProxy) {
		this.impuestosProxy = impuestosProxy;
	}

	public double calculaPrecioTotal(TipoIva tipo, 
	              double precioBase, double descuento) 
				throws BusinessException {

		Double impuesto = Double.valueOf(0.0);
		if (precioBase < 0) {
			throw new BusinessException("El precio es inválido");
		}
		if (descuento < 0 || descuento > 1) {
	     	throw new BusinessException(
	                           "El descuento es inválido");
		}
		if (tipo == null) {
			throw new BusinessException("Tipo de Iva inválido");
		}
		List<ElementoIva> elementosIva;
		try {
			elementosIva = impuestosProxy.obtenerElementosIva();
		} catch (IOException e) {
			throw new BusinessException(
	         "No se pudo conectar al servidor de Impuestos");
		}
			
		impuesto = elementosIva.stream()
			    .filter(e -> tipo.name().equals(e.getTipoIva()))
			    .map(ElementoIva::getPorcentaje)
			    .findFirst()
			    .orElse(null);
			
		if (impuesto == null) {
			throw new BusinessException(
	            "No existen datos del tipo de IVA");
		}
		double precioDescuento = precioBase * (1 - descuento);
		return precioDescuento * (1 + impuesto);
	}

	
}
