package acme.productos;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class MockImpuestosProxy implements ImpuestosProxy {
  private boolean generarError = false;

  public MockImpuestosProxy(boolean generarError) {
	this.generarError = generarError;
  }
	
  @Override
  public List<ElementoIva> obtenerElementosIva() 
      throws IOException {
  	 if (generarError) {
		throw new IOException(
           "No se pudo conectar al servidor");
   	 }
    return Arrays.asList(
                 new ElementoIva("NORMAL", 0.21),
			   new ElementoIva("REDUCIDO", 0.10),
  			   new ElementoIva("SUPER_REDUCIDO", 0.04));
  }
}
