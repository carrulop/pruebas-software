package acme.productos;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import acme.BusinessException;

public class ProductosServiceTest {
	
  private ProductosService productoServiceOk;
  private ProductosService productoServiceFallo;
	
  @BeforeEach
  public void setup() {
	productoServiceOk = new ProductosService(
              new MockImpuestosProxy(false));
	productoServiceFallo = new ProductosService(
              new MockImpuestosProxy(true));
  }

  @Test
  public void testCalcularPrecioTotal1() {
	double resultadoReal = assertDoesNotThrow(
      () -> productoServiceOk.calculaPrecioTotal(
              TipoIva.NORMAL, 1000.0, 0.25));
	double resultadoEsperado = 907.5;
	assertEquals(resultadoEsperado, resultadoReal, 0.01);
  }
   
  @Test
  public void testCalcularPrecioTotal8() {
	BusinessException exception = assertThrows(
          BusinessException.class,
		() -> productoServiceFallo.calculaPrecioTotal(
                      TipoIva.NORMAL, 1500, 0.20));
	assertEquals("No se pudo conectar al servidor de Impuestos", 
                  exception.getMessage());
  }

}
