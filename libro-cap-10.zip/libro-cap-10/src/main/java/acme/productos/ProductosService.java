package acme.productos;

public class ProductosService {

  public double calculaPrecioTotal(TipoIva tipo, 
    double precioBase, double descuento) 
    throws BusinessException {
	double impuesto = 0;
	if (precioBase < 0) {
		throw new BusinessException("El precio es invalido");
	}
	if (descuento < 0 || descuento > 1) {
		throw new BusinessException(
                 "El descuento es invalido");
	}
	if (tipo == null) {
		throw new BusinessException("Tipo de Iva invalido");
	}
	if (tipo == TipoIva.NORMAL) {
		impuesto = 0.21;
	} else if (tipo == TipoIva.REDUCIDO) {
		impuesto = 0.10;
	} else if (tipo == TipoIva.SUPER_REDUCIDO) {
		impuesto = 0.04;
	}
	double precioDescuento = precioBase * (1 - descuento);
	return precioDescuento * (1 + impuesto);
  }
	
  public double calculaPuntosDescuento(double precioTotal) 
        throws BusinessException {
	if (precioTotal < 0) {
		throw new BusinessException("Precio invalido");
	}
	double porcentajeDescuento = 0;
	if (precioTotal > 500 && precioTotal < 1000) {
		porcentajeDescuento = 0.1;
	} else if (precioTotal >= 1000 && precioTotal <= 5000) {
		porcentajeDescuento = 0.3;
	} else if (precioTotal > 5000){
		return 1550;
	}
	return precioTotal * porcentajeDescuento;	
  }
}
