package acme.productos;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ProductosServiceTest {
	
  private ProductosService productoService;
	
  @BeforeEach
  public void setup() {
	productoService = new ProductosService();
  }

  @Test
  public void testCalcularPrecioTotal1() {
	double resultadoReal = assertDoesNotThrow(
               () -> productoService.calculaPrecioTotal(
                            TipoIva.NORMAL, 1000.0, 0.25));
	double resultadoEsperado = 907.5;
	assertEquals(resultadoEsperado, resultadoReal, 0.01);
	}

  @Test
  public void testCalcularPrecioTotal2() {
	double resultadoReal = assertDoesNotThrow(
        () -> productoService.calculaPrecioTotal(
                TipoIva.REDUCIDO, 1000.0, 0));
 	double resultadoEsperado = 1100.0;
	assertEquals(resultadoEsperado, resultadoReal, 0.01);
  }

  @Test
  public void testCalcularPrecioTotal3() {
	double resultadoReal = assertDoesNotThrow(
         () -> productoService.calculaPrecioTotal(
                 TipoIva.SUPER_REDUCIDO, 1000, 0.5));
 	double resultadoEsperado = 520.0;
	assertEquals(resultadoEsperado, resultadoReal, 0.01);
  }

  @Test
  public void testCalcularPrecioTotal4()  {
    BusinessException exception = assertThrows(
        BusinessException.class,
	  () -> productoService.calculaPrecioTotal(
                 TipoIva.NORMAL, -1, 0.0));
    assertEquals("El precio es invalido",
                 exception.getMessage());
  }

  @Test
  public void testCalcularPrecioTotal5() {
	BusinessException exception = assertThrows(
          BusinessException.class,
				() -> productoService.calculaPrecioTotal(
                               TipoIva.NORMAL, 1500, -1.0));
	assertEquals("El descuento es invalido", 
                  exception.getMessage());
  }
	
  @Test
  public void testCalcularPrecioTotal6() {
	BusinessException exception = assertThrows(
         BusinessException.class,
		() -> productoService.calculaPrecioTotal(
                       TipoIva.NORMAL, 1500, 1.1));
	assertEquals("El descuento es invalido", 
                  exception.getMessage());
  }

  @Test
  public void testCalcularPrecioTotal7() {
	BusinessException exception = assertThrows(
           BusinessException.class,
      	() -> productoService.calculaPrecioTotal(
                        null, 1500, 0.20));
	assertEquals("Tipo de Iva invalido", 
                  exception.getMessage());
  }

  @Test
  public void testCalcularPuntosDescuento1() {
	double resultadoReal = assertDoesNotThrow(
         () -> productoService.calculaPuntosDescuento(500.0));
	double resultadoEsperado = 0.0;
	assertEquals(resultadoEsperado, resultadoReal, 0.01);
  }

  @Test
  public void testCalcularPuntosDescuento2() {
	double resultadoReal = assertDoesNotThrow(
         () -> productoService.calculaPuntosDescuento(500.01));
	double resultadoEsperado = 50.001;
	assertEquals(resultadoEsperado, resultadoReal, 0.01);
  }

  @Test
  public void testCalcularPuntosDescuento3() {
	double resultadoReal = assertDoesNotThrow(
        () -> productoService.calculaPuntosDescuento(999.99));
	double resultadoEsperado = 99.999;
	assertEquals(resultadoEsperado, resultadoReal, 0.0001);
  }

  @Test
  public void testCalcularPuntosDescuento4() {
	double resultadoReal = assertDoesNotThrow(
          () -> productoService.calculaPuntosDescuento(1000.0));
	double resultadoEsperado = 300.0;
	assertEquals(resultadoEsperado, resultadoReal, 0.01);
  }

  @Test
  public void testCalcularPuntosDescuento5() {
	double resultadoReal = assertDoesNotThrow(
           () -> productoService.calculaPuntosDescuento(5000.0));
	double resultadoEsperado = 1500.0;
	assertEquals(resultadoEsperado, resultadoReal, 0.01);
  }

  @Test
  public void testCalcularPuntosDescuento6() {
	double resultadoReal = assertDoesNotThrow(
           () -> productoService.calculaPuntosDescuento(5500));
	double resultadoEsperado = 1550;
	assertEquals(resultadoEsperado, resultadoReal, 0.01);
  }

  @Test
  public void testCalcularPuntosDescuento7() {
	BusinessException exception = assertThrows(
           BusinessException.class,
		() -> productoService.calculaPuntosDescuento(-1.0));
	assertEquals("Precio invalido", exception.getMessage());
  }
}
