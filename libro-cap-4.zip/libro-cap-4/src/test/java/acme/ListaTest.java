package acme;

import static org.junit.jupiter.api.Assertions.*;
import java.util.*;
import org.junit.jupiter.api.Test;

class ListaTest {
  @Test
  public void testListaVaciaIsEmpty() {
	List<String> lista = new ArrayList<>();
	assertTrue(lista.isEmpty());
  }
	
  @Test
  public void testListaVaciaLongitud() {
	List<String> lista = new ArrayList<>();
	assertEquals(0, lista.size());
  }
	
  @Test
  public void testListaNoVaciaIsEmpty() {
    List<String> lista = Arrays.asList("verde", 
  "azul", "blanco");
    assertFalse(lista.isEmpty());
  }
	
  @Test
  public void testListaNoVaciaLongitud() {
    List<String> lista = Arrays.asList("verde", 
                                       "azul", "blanco");
    assertEquals(3, lista.size());
  }
}
