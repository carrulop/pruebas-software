package acme;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Tag;

@Tag("PILA")
@DisplayName("Pruebas Unitarias para la Pila de Enteros")
public class PilaEnterosTest {

	@BeforeAll
	public static void inicioClase() {
		// Para este ejemplo no hacemos nada, pero exponemos el método
		// por motivos didácticos exclusivamente.
		System.out.println("Ejecutamos el método inicioClase()");
	}

	@AfterAll
	public static void finClase() {
		// Para este ejemplo no hacemos nada, pero exponemos el
		// método por motivos didácticos exclusivamente.
		System.out.println("Ejecutamos el método finClase()");
	}

	@BeforeEach
	public void testStart() {
		// Para este ejemplo no hacemos nada, pero exponemos el
		// método por motivos didácticos exclusivamente.
		System.out.println("Ejecutamos el método testStart()");
	}

	@AfterEach
	public void testEnd() {
		// Para este ejemplo no hacemos nada, pero exponemos el método
		// por motivos didácticos exclusivamente.
		System.out.println("Ejecutamos el método testEnd()");
	}

	@Test
	@DisplayName("Debería insertar un elemento en la pila")
	public void deberiaInsertarEnLaPila() {
		PilaEnteros pila = new PilaEnteros();
		pila.meter(5);
		assertEquals(1, pila.numeroElementos(), "Se ha añadido un elemento a la pila");
		pila.meter(4);
		assertEquals(2, pila.numeroElementos(), "Se ha añadido dos elementos a la pila");
	}

	@Test
	@DisplayName("Debería eliminar un elemento de la pila " 
	           + "en el orden correcto")
	public void deberiaEliminarEnLaPilaEnElOrdenCorrecto() {
		PilaEnteros pila = new PilaEnteros();
		try {
			pila.meter(1);
			pila.meter(2);
			pila.meter(3);
			assertEquals(3, pila.numeroElementos(), "Se han añadido tres elementos");
			Integer tercerElemento = pila.sacar();
			Integer segundoElemento = pila.sacar();
			Integer primerElemento = pila.sacar();
			assertEquals(0, pila.numeroElementos(), "La pila ahora está vacía");
			assertEquals(3, tercerElemento.intValue(), "El último elemento es el primero que se saca");
			assertEquals(2, segundoElemento.intValue(), "El segundo elemento es el segundo que se saca");
			assertEquals(1, primerElemento.intValue(), "El primer elemento es el último que se saca");
		} catch (Exception e) {
			fail("Se produjo una excepción inesperada.");
		}
	}

	@Test
    @DisplayName("Debería lanzar una excepción si elimina " 
              + "una pila vacía")
	public void deberiaLanzarExcepcionCuandoEliminaUnaPilaVacia() {
		PilaEnteros pila = new PilaEnteros();
		try {
			pila.sacar();
			fail("Debería producirse una excepción.");
		} catch (Exception e) {
			assertEquals("PILA VACIA", e.getMessage(), "Se produce la excepción Pila vacia");
		}
	}

	@Disabled("Necesita rehacerse este método")
	@Test
    @DisplayName("Debería lanzar una excepción si mete un valor "
	             + " inválido")
	public void deberiaLanzarExcepcionPorValorInvalido() {
		PilaEnteros pila = new PilaEnteros();
		IllegalArgumentException excepcion = assertThrows(IllegalArgumentException.class, () -> pila.meter(null));
		assertEquals("VALOR NULO", excepcion.getMessage(), "Se produce la excepción Valor nulo");
	}

}
