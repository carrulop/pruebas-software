  package acme;

  import org.junit.jupiter.api.*;

  public class TestAnidado {

	@BeforeEach
	void beforeEach() {
		System.out.println("TestAnidado:beforeEach");
	}
	
	@Nested
	class PrimeraClaseAnidada {
		@BeforeEach
		void beforeEach() {
			System.out.println(
                    "PrimeraClaseAnidada:beforeEach");
		}
		@Test
		void test() {
			System.out.println("PrimeraClaseAnidada:test");
		}
	}
	
	@Nested
	class SegundaClaseAnidada {
		@BeforeEach
		void beforeEach() {
			System.out.println(
   "SegundaClaseAnidada:beforeEach");
		}
		@Test
		void test() {
			System.out.println("SegundaClaseAnidada:test");
		}
	}	
  }
