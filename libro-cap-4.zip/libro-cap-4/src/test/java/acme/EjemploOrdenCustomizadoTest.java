package acme;

  import org.junit.jupiter.api.*;

  @TestMethodOrder(CustomOrder.class)
  public class EjemploOrdenCustomizadoTest {

	@Test
	void testA() {
		System.out.println("Ejecuto Test A");
	}
  
     @Test
	void testa() {
		System.out.println("Ejecuto Test a");
	}
	
	@Test
	void testB() {
		System.out.println("Ejecuto Test B");
	}
	
	@Test
	void testC() {
		System.out.println("Ejecuto Test C");
	}
  }
