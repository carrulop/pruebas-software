package acme;

import static org.junit.jupiter.api.Assertions.*;
import java.util.*;
import org.junit.jupiter.api.*;

class ListaTestAnidada {
  @Nested
  class ListaEstaVacia {
	List<String> listaVacia = new ArrayList<>();
		
	@Test
	public void testIsEmpty() {
		assertTrue(listaVacia.isEmpty());
	}
		
	@Test
	public void testLongitud() {
		assertEquals(0, listaVacia.size());
	}
  }
	
  @Nested
  class ListaNoEstaVacia {
	List<String> lista = Arrays.asList(
"verde", "azul", "blanco");
	
	@Test
	public void testIsEmpty() {
		assertFalse(lista.isEmpty());
	}

	@Test
	public void testLongitud() {
		assertEquals(3, lista.size());
	}		
  }
}
