package acme;

  import org.junit.jupiter.api.*;

  //@TestMethodOrder(MethodOrderer.MethodName.class)
  //@TestMethodOrder(MethodOrderer.DisplayName.class)
  //@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
  @TestMethodOrder(MethodOrderer.Random.class)
  public class EjemploOrdenTest {

	@Test
	@DisplayName("Test A")
	@Order(3)
	void testUno() {
		System.out.println("Ejecuto Test 1");
	}
	
	@Test
	@DisplayName("Test B")
	@Order(2)
	void testDos() {
		System.out.println("Ejecuto Test 2");
	}
	
	@Test
	@DisplayName("Test C")
	@Order(1)
	void testTres() {
		System.out.println("Ejecuto Test 3");
	}
  }
