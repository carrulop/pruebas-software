package acme;

import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

public class EjemplosTest {
	@Test
	@EnabledOnOs({OS.WINDOWS, OS.LINUX})
	public void deberiaEjecutarseEnWindowsYLinux() {
	   
	}
		
	@Test
	@Timeout(value = 5, unit = TimeUnit.MINUTES)
	void deberiaFallarDespuesDeUnSegundo() throws InterruptedException {
	    Thread.sleep(1500);
	}


}
