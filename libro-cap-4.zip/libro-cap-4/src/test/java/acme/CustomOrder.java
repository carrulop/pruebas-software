package acme;

  import org.junit.jupiter.api.MethodDescriptor;
  import org.junit.jupiter.api.MethodOrderer;
  import org.junit.jupiter.api.MethodOrdererContext;

  public class CustomOrder implements MethodOrderer {
    @Override
    public void orderMethods(MethodOrdererContext context) {
  	 context.getMethodDescriptors().sort(
	(MethodDescriptor metodo1, MethodDescriptor metodo2) ->  
             metodo1.getMethod().getName().compareToIgnoreCase(
                  metodo2.getMethod().getName()));
    }
  }
