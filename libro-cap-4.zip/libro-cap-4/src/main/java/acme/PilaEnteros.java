package acme;

  import java.util.ArrayList;
  import java.util.List;
  public class PilaEnteros {
    private List<Integer> lista = null;
    
    public PilaEnteros() {
        this.lista = new ArrayList<>();
    }
    
    public void meter(Integer valor) {
		if (valor == null) {
			throw new IllegalArgumentException("VALOR NULO");
		}
		this.lista.add(valor);
	}

    
    public Integer sacar() throws Exception {
        if (lista.size() > 0) {
            Integer elemento = lista.get(lista.size() - 1);
            lista.remove(lista.size() - 1);
            
            return elemento;
        } else {
            throw new Exception("PILA VACIA");
        }
    }
    
    public int numeroElementos() {
        return this.lista.size();
    }    
  }
