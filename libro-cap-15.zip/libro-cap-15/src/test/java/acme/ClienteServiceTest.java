package acme;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ClienteServiceTest {

  @Mock
  private ClienteRepository clienteRepositoryMock;
   
  @Mock
  private NotificacionRepository notificacionRepositoryMock;

  @Captor
  ArgumentCaptor<Integer> argId; // (1)

  @InjectMocks
  private ClienteService clienteService;

  @Test
  void testProcesarCliente() {
 	  clienteService.procesarCliente(1, 
             Arrays.asList("Hola", "Mundo"));

     ArgumentCaptor<Integer> argId = ArgumentCaptor.forClass(
                                     Integer.class); // (1)

     verify(clienteRepositoryMock, Mockito.times(1))
                       .leerCliente(argId.capture()); // (2)

     Integer idClienteRecibido = argId.getValue();  // (3)

     assertEquals(1, idClienteRecibido);  
  }
  
  @Test
  void testProcesarClienteQueFalla() {
    ClienteDto clienteMock = mock(ClienteDto.class);
    when(clienteRepositoryMock.leerCliente(anyInt()))
               .thenReturn(clienteMock);

    clienteService.procesarCliente(1, 
             Arrays.asList("Hola", "Mundo"));

    ArgumentCaptor<String> argAviso = ArgumentCaptor.forClass(
                                    String.class); 
  
    verify(notificacionRepositoryMock, Mockito.times(2))
         .notificarCliente(clienteMock,  argAviso.capture());
  }

  @Test
  void testProcesarClienteQueFunciona() {
    ClienteDto clienteMock = mock(ClienteDto.class);
    when(clienteRepositoryMock.leerCliente(anyInt()))
               .thenReturn(clienteMock);

    clienteService.procesarCliente(1, 
             Arrays.asList("Hola", "Mundo"));


    ArgumentCaptor<String> argAviso = ArgumentCaptor.forClass(
                                    String.class); 
  
    verify(notificacionRepositoryMock, Mockito.times(2))
         .notificarCliente(Mockito.eq(clienteMock),  
                           argAviso.capture());
    
    List<String> avisos = argAviso.getAllValues();
    assertEquals(2, avisos.size());
    assertEquals("Hola", avisos.get(0));
    assertEquals("Mundo", avisos.get(1));
  }

  @Test
  void testProcesarClienteConAnotacionCaptor() {
   	  clienteService.procesarCliente(1, 
               Arrays.asList("Hola", "Mundo"));

       verify(clienteRepositoryMock, Mockito.times(1))
                         .leerCliente(argId.capture()); // (2)

       Integer idClienteRecibido = argId.getValue();  // (3)

       assertEquals(1, idClienteRecibido);  
    }


}
