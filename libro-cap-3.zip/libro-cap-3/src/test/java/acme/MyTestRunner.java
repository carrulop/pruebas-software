package acme;

import static org.junit.platform.engine.discovery.DiscoverySelectors.*;
import java.util.List;
import org.junit.platform.launcher.Launcher;
import org.junit.platform.launcher.LauncherDiscoveryRequest;
import org.junit.platform.launcher.core
.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners  
.SummaryGeneratingListener;
import org.junit.platform.launcher.listeners
.TestExecutionSummary;
import org.junit.platform.launcher.listeners
          .TestExecutionSummary.Failure;

public class MyTestRunner {
	
  public static void main(String[] args) {
	// (1) Seleccionamos los tests que queremos ejecutar
	final LauncherDiscoveryRequest request = 
  LauncherDiscoveryRequestBuilder.request().selectors(
    selectClass(PilaEnterosTest.class)).build();

	// (2) Construimos el lanzador de los tests
	final Launcher launcher = LauncherFactory.create();

	// (3) Construimos el listener para obtener los resultados
	final SummaryGeneratingListener listener = 
new SummaryGeneratingListener();
	launcher.registerTestExecutionListeners(listener);

	// (4) Ejecutamos los tests
	launcher.execute(request);

	// (5) Procesamos los resultados de los tests
	TestExecutionSummary summary = listener.getSummary();
	long testFoundCount = summary.getTestsFoundCount();
	List<Failure> failures = summary.getFailures();
	System.out.println("getTestsSucceededCount() - " 
+ summary.getTestsSucceededCount());
	failures.forEach(failure -> System.out.println("failure - " 
+ failure.getException()));
  }
}
