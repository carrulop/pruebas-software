package acme;

import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

public class CalculadoraTest {

  @Test
  void deberiaSumar() {
	// Creamos una instancia de la clase a probar
	Calculadora calculadora = new Calculadora();
		
	// Preparamos la ejecución de la prueba
	int paramA = 5;
	int paramB = 10;
	int resultado;
		
	// Ejecutamos la prueba
	resultado = calculadora.sumar(paramA, paramB);
		
	// Comprobamos el resultado de la prueba
	assertTrue(resultado == 15, "Debería sumar correctamente.");
  }
  
  @Test
  void deberiaRestar() {
	// Creamos una instancia de la clase a probar
	Calculadora calculadora = new Calculadora();
	
	// Preparamos la ejecución de la prueba
	int paramA = 5;
	int paramB = 10;
	int resultado;
		
	// Ejecutamos la prueba
	resultado = calculadora.restar(paramA, paramB);
		
	// Comprobamos el resultado de la prueba
	assertTrue(resultado == -5, "Debería restar correctamente.");
  }

}
