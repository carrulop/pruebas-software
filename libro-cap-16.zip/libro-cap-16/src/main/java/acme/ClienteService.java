package acme;

import java.util.List;

public class ClienteService {

  private ClienteRepository clienteRepository;
  private NotificacionRepository notificacionRepository;

  public ClienteService(ClienteRepository clienteRepository, 
            NotificacionRepository notificacionRepository) {
	  this.clienteRepository = clienteRepository;
	  this.notificacionRepository = notificacionRepository;
  }

  public void procesarCliente(Integer idCliente, 
               String nuevoEstado,  List<String> avisos) {
	 ClienteDto cliente = clienteRepository.leerCliente(
                                             idCliente);
    if (cliente == null) {
		throw new IllegalArgumentException(
                           "No existe el cliente");
  	 }
    if (nuevoEstado != null) {
  	  clienteRepository.actualizarCliente(cliente, nuevoEstado);        
    }

    if (avisos != null) {
      for (String aviso : avisos) {
		notificacionRepository.notificarCliente(cliente,
                                                aviso);
      }
    }
  }
}
