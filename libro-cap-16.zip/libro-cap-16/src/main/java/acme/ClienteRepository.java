package acme;

public interface ClienteRepository {

	ClienteDto leerCliente(Integer idCliente);

	void actualizarCliente(ClienteDto cliente, String nuevoEstado);

}
