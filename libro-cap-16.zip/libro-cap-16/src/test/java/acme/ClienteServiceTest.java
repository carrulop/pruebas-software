package acme;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ClienteServiceTest {

	private static final String MENSAJE_2 = "Mensaje 2";
	private static final String MENSAJE_1 = "Mensaje 1";
	private static final int ID_CLIENTE = 1;
	private static final String ESTADO_ENVIADO = "ENVIADO";

	@Mock
	private ClienteRepository clienteRepositoryMock;

	@Mock
	private NotificacionRepository notificacionRepositoryMock;

	@InjectMocks
	private ClienteService service;

@Captor
private ArgumentCaptor<String> argAvisos;

@Mock
private ClienteDto clienteMock;

private void configurarMock(ClienteDto cliente) {
		when(clienteRepositoryMock.leerCliente(ID_CLIENTE))
               .thenReturn(cliente);
}

	@Test
	void testClienteExisteConNuevoEstadoYAvisos() {
		// Preparar el caso de prueba
		configurarMock(clienteMock);

		// Ejecutar la prueba
		service.procesarCliente(ID_CLIENTE, ESTADO_ENVIADO,
                         Arrays.asList(MENSAJE_1, MENSAJE_2));

		// Verificar los resultados
		verify(clienteRepositoryMock, times(1))
                              .leerCliente(ID_CLIENTE);

		verify(clienteRepositoryMock, times(1))
                         .actualizarCliente(eq(clienteMock), 
                                            eq(ESTADO_ENVIADO));

		verify(notificacionRepositoryMock, times(2))
                .notificarCliente(eq(clienteMock),
                                  argAvisos.capture());

		List<String> avisos = argAvisos.getAllValues();
		assertEquals(MENSAJE_1, avisos.get(0));
		assertEquals(MENSAJE_2, avisos.get(1));
	}
	
	  @Test
	  void testClienteExisteSinEstadoYConAvisos() {

	    // Preparar el caso de prueba
	    configurarMock(clienteMock);

	    // Ejecutar la prueba
	    service.procesarCliente(ID_CLIENTE, null,
	                            Arrays.asList(MENSAJE_1));

	    // Verificar los resultados
	    verify(clienteRepositoryMock, times(1))
						  .leerCliente(ID_CLIENTE);

	    verify(clienteRepositoryMock, never())
					 .actualizarCliente(any(), any());

	    verify(notificacionRepositoryMock, times(1))
	      .notificarCliente(eq(clienteMock), argAvisos.capture());
	    String aviso = argAvisos.getValue();
	    assertEquals(MENSAJE_1, aviso);
	  }

	  @Test
	  void testClienteExisteSinEstadoYSinAvisos() {
	    // Preparar el caso de prueba
	    configurarMock(clienteMock);

	    // Ejecutar la prueba
	    service.procesarCliente(ID_CLIENTE, null, new ArrayList<>());

	    // Verificar los resultados
	    verify(clienteRepositoryMock, times(1))
					  .leerCliente(ID_CLIENTE);

	    Mockito.verifyNoMoreInteractions(clienteRepositoryMock, 
	                                     notificacionRepositoryMock);
	  }

	  @Test
	  void testClienteNoExiste() {
		// Ejecutar la prueba
		IllegalArgumentException exception = assertThrows(
	          IllegalArgumentException.class,
		     () -> service.procesarCliente(0, ESTADO_ENVIADO,
	                               Arrays.asList(MENSAJE_1)));

		// Verificar los resultados
		verify(clienteRepositoryMock, times(1)).leerCliente(0);

		Mockito.verifyNoMoreInteractions(clienteRepositoryMock,
	                         notificacionRepositoryMock);

		assertEquals("No existe el cliente", 
	                   exception.getMessage());
	  }

  }
