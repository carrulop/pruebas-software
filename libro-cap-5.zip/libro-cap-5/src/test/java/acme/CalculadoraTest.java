package acme;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class CalculadoraTest {

	@Test
	void verificarDivisionEntreCeroLanzaExcepcion() {
		Calculadora calculadora = new Calculadora();
		ArithmeticException exception = assertThrows(ArithmeticException.class, () -> calculadora.dividir(5, 0));

		assertEquals("/ by zero", exception.getMessage());
	}

}
