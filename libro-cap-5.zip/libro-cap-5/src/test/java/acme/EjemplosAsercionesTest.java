package acme;

import static org.junit.jupiter.api.Assertions.*;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

public class EjemplosAsercionesTest {

	@Test
	void testAsercionesBooleanas() {
		assertTrue(true); // Pasará
		assertTrue(8 % 2 == 0, "El número 8 es par"); // Pasará
		assertTrue(false); // Fallará
		assertFalse(false); // Pasará
		assertFalse(8 == 5); // Pasará
		assertTrue(8 > 5); // Pasará

	}

	@Test
	void testAsercionesIgualdad() {
		int valor = 5;
		String cadena = "Hola";
		assertEquals(5, valor, "Valor debe ser 5"); // Pasará
		assertEquals(3, valor, "Valor debe ser 3"); // Fallará
		assertEquals("Hola", cadena); // Pasará
		assertNotEquals(3, valor, "Valor no es 3"); // Pasará
		assertNotEquals("Arlen", cadena); // Pasará

		int a[] = { 1, 2, 3 };
		int b[] = { 1, 2, 3 };
		int c[] = { 3, 1, 2 };
		int d[] = { 1, 2 };
		assertArrayEquals(a, b); // Pasará
		assertArrayEquals(a, c); // Fallará, ya que el orden de los
									// elementos no coinciden
		assertArrayEquals(b, d); // Fallará

	}

	@Test
	void asercionesObjetos() {
		Persona persona1 = new Persona("Arlen", "Mongalier");
		Persona persona2 = new Persona("Arlen", "Mongalier");
		Persona personaNula = null;
		Persona persona3 = persona1; // Ambas son la misma instancia
		assertNull(personaNula); // Pasará
		assertNull(persona1); // Fallará
		assertNotNull(persona1); // Pasará
		assertEquals(persona1, persona2); // Pasará
		assertSame(persona1, persona2); // Fallará
		assertNotSame(persona1, persona2); // Pasará
		assertSame(persona1, persona3); // Pasará

	}

	@Test
	void testAsercionesTiempoEjecucion() {
		String mensaje = assertTimeout(Duration.ofMillis(1000), () -> {
			Thread.sleep(500);
			return "Hola";
		});
		assertEquals("Hola", mensaje);

	}

	@Test
	void testAsercionesTiempoEjecucionNoPasa() {
		String mensaje = assertTimeout(Duration.ofMillis(1000), () -> {
			Thread.sleep(2000);
			return "Hola";
		});
	}

	@Test
	void testAsercionesAgrupadas() {
		Persona personaActual = new Persona("Arlen", "Mongalier");
		Persona personaEsperada = new Persona("Phobos", "Perland");
		assertAll(() -> assertEquals(personaEsperada.getNombre(), personaActual.getNombre()),
				() -> assertEquals(personaEsperada.getApellidos(), personaActual.getApellidos()));

	}

	@Test
	void testAsercionFail() {
		fail("FALLO – Test no completado");
	}

	@Test
	void testAssercionLineMatch() {
		List<String> esperados = Arrays.asList("Arlen", "\\d+", "JUnit");
		List<String> actual = Arrays.asList("Arlen", "21", "JUnit");

		assertLinesMatch(esperados, actual);

	}
}
