package acme;

public class Calculadora {

	public int dividir(int a, int b) {
		return a / b;
	}

}
