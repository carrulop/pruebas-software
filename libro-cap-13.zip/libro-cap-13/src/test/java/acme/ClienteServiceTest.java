package acme;

import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ClienteServiceTest {

	@Mock
	  private ClienteRepository clienteRepository;
	  @Mock
	  private NotificacionRepository notificacionRepository;
	  @InjectMocks
	  private ClienteService clienteService;

	  @Test
	  void testProcesarClienteEjecutaAccionesEnOrden() {
	     
	     clienteService.procesarCliente(1, 
	                      Arrays.asList("Hola", "Mundo"));    //(1)

	     InOrder inOrder = Mockito.inOrder(clienteRepository,
	                                notificacionRepository) ; //(2)

	     inOrder.verify(clienteRepository).leerCliente(1) ;   //(3)

	     inOrder.verify(clienteRepository)
	                     .actualizarCliente(Mockito.any());   //(4)

	     inOrder.verify(notificacionRepository, Mockito.times(2))
	                 .notificarCliente(Mockito.any(),
	                                   Mockito.any()); //(5)

	  }

	
}
