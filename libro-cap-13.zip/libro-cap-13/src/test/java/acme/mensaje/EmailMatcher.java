package acme.mensaje;

  import org.mockito.ArgumentMatcher;

  public class EmailMatcher 
     implements ArgumentMatcher<Email> { // (1)

	private Email valorEsperado; // (2)

     public EmailMatcher(Email valorEsperado) {  // (3)
        this.valorEsperado = valorEsperado;
     }
	
	@Override
	public boolean matches(Email valorActual) { // (4)
		return valorActual.getFrom().equals(
                          valorEsperado.getFrom()) &&
		       valorActual.getTo().equals(
                          valorEsperado.getTo()) &&
		      valorActual.getText().equals(
                          valorEsperado.getText());
	}
  }
