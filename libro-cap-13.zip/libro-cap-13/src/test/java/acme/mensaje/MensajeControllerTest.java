package acme.mensaje;

import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class MensajeControllerTest {

	@Mock
	private EmailService emailServiceMock;

	@InjectMocks
	private MensajeController mensajeController;

	@Test
	void testEnviarMensaje() {
		MensajeDTO mensaje = new MensajeDTO();
		mensaje.setDestinatario("Phobos");
		mensaje.setRemitente("Arlen");
		mensaje.setMensaje("¡Hola!");

		mensajeController.enviarMensaje(mensaje);

		verify(emailServiceMock, Mockito.times(1)).enviarEmail(Mockito.any(Email.class));
	}

	@Test
	void testEnviarMensajeUsandoEmailMatcher() {
		MensajeDTO mensaje = new MensajeDTO();
		mensaje.setDestinatario("Phobos");
		mensaje.setRemitente("Arlen");
		mensaje.setMensaje("¡Hola!");

		mensajeController.enviarMensaje(mensaje);

		Email emailEsperado = new Email();
		emailEsperado.setTo("Phobos");
		emailEsperado.setFrom("Arlen");
		emailEsperado.setText("¡Hola!");

		verify(emailServiceMock, Mockito.times(1)).enviarEmail(Mockito.argThat(new EmailMatcher(emailEsperado)));
	}

}
