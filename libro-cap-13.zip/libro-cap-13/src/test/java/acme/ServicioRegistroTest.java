package acme;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

public class ServicioRegistroTest {

	@Test
	void testActualizarServicioRegistro() {
		ServicioRegistro servicioRegistroMock = Mockito.mock(ServicioRegistro.class); // (1)

		final Date fechaHoy = new Date();

		Mockito.doAnswer(new Answer<Void>() { // (2)

			@Override
			public Void answer(InvocationOnMock invocation) // (3)
					throws Throwable {
				Registro registro = invocation.getArgument(0, Registro.class); // (4)

				registro.setFechaModificacion(fechaHoy); // (5)
				return null; // (6)
			}
		}).when(servicioRegistroMock) // (7)
				.actualizar(ArgumentMatchers.any()); // (8)

		Registro registro = new Registro();
		servicioRegistroMock.actualizar(registro);
		assertEquals(fechaHoy, registro.getFechaModificacion());

	}

	@Test
	void testVerify() {
		// Crear el mock
		Persona test = Mockito.mock(Persona.class);

		// Ejecutar el método del mock
		test.setNombre("Al menos una vez");
		test.setNombre("Al menos una vez");
		test.setNombre("Llamado tres veces");
		test.setNombre("Llamado tres veces");
		test.setNombre("Llamado tres veces");
		test.setNombre("Llamado como mucho tres veces");

		// Verificar
		Mockito.verify(test, Mockito.never()).setNombre("nunca llamado");

		Mockito.verify(test, Mockito.atLeastOnce()).setNombre("Al menos una vez");

		Mockito.verify(test, Mockito.times(3)).setNombre("Llamado tres veces");

		Mockito.verify(test, Mockito.atMost(3)).setNombre("Llamado como mucho tres veces");

		Mockito.verify(test, Mockito.times(6)).setNombre(Mockito.anyString());

	}

}
