package acme.mensaje;

public class MensajeController {

	private EmailService emailService;
	
	public MensajeController(EmailService emailService) {
		this.emailService = emailService;
	}
	
	public void enviarMensaje(MensajeDTO mensaje) {
		Email email = new Email();
		email.setFrom(mensaje.getRemitente());
		email.setTo(mensaje.getDestinatario());
		email.setText(mensaje.getMensaje());
		emailService.enviarEmail(email);
	}
}
