package acme.mensaje;

public class MensajeDTO {

	private String remitente;

	private String destinatario;

	private String mensaje;

	public MensajeDTO() {
		
	}
	
	public MensajeDTO(String remitente, String destinatario, String mensaje) {
		super();
		this.remitente = remitente;
		this.destinatario = destinatario;
		this.mensaje = mensaje;
	}

	public String getRemitente() {
		return remitente;
	}

	public void setRemitente(String remitente) {
		this.remitente = remitente;
	}

	public String getDestinatario() {
		return destinatario;
	}

	public void setDestinatario(String destinatario) {
		this.destinatario = destinatario;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	@Override
	public String toString() {
		return "MensajeDTO [remitente=" + remitente + ", destinatario=" + destinatario + ", mensaje=" + mensaje + "]";
	}

}
