package acme.mensaje;

public interface EmailService {

	void enviarEmail(Email email);

}
