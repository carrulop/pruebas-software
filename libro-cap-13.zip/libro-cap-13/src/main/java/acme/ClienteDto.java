package acme;

public class ClienteDto {

}
