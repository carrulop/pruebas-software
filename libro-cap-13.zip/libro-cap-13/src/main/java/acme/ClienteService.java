package acme;

import java.util.List;

public class ClienteService {

    private ClienteRepository clienteRepository;
    private NotificacionRepository notificacionRepository;


    public void procesarCliente(Integer idCliente, 
                                List<String> avisos) {

      ClienteDto cliente = clienteRepository.leerCliente(
                                       idCliente);
	 clienteRepository.actualizarCliente(cliente);

      for (String aviso : avisos) {
        notificacionRepository.notificarCliente(cliente, aviso);
      }
    }
  }
