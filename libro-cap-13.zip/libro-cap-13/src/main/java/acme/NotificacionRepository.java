package acme;

public interface NotificacionRepository {

	void notificarCliente(ClienteDto cliente, String aviso);

}
