package acme;

import java.util.Date;

public class Registro {

	private Date fechaModificacion;
	
	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}
	
	
	
	

}
