package acme;

import java.util.Date;

public class ServicioRegistro {
    
    public void actualizar(Registro registro) {
       // Hacer algo con el registro, por ejemplo, almacenarlo
       //  en una Base de Datos
       
       registro.setFechaModificacion(new Date()); // (1)
    }
  }
