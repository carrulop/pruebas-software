package acme.ejemplo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest // (1)
public class EjemploApplicationTest {

	@Test // (2)
	void contextoCarga() {	
	}
}
