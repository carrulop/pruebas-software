  package acme.ejemplo.servicios;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest	//(1)
public class PilaEnterosServiceTest {

  @Autowired
  private PilaEnterosService pila; // (2)

  @Test
  public void deberiaInsertarEnLaPila() {
	pila.meter(5);
	assertEquals(1, pila.numeroElementos(), 
                "Se ha añadido un elemento a la pila");
  	pila.meter(4);
	assertEquals(2, pila.numeroElementos(), 
                "Se ha añadido dos elementos a la pila");
  }

  @Test
  public void deberiaEliminarEnLaPilaEnElOrdenCorrecto() {
	try {
		pila.meter(1);
		pila.meter(2);
		pila.meter(3);
		assertEquals(3, pila.numeroElementos(), 
                      "Se han añadido tres elementos");
		Integer tercerElemento = pila.sacar();
		Integer segundoElemento = pila.sacar();
		Integer primerElemento = pila.sacar();
		assertEquals(0, pila.numeroElementos(), 
                     "La pila ahora está vacía");
		assertEquals(3, tercerElemento.intValue(), 
            "El último elemento es el primero que se saca");
		assertEquals(2, segundoElemento.intValue(), 
            "El segundo elemento es el segundo que se saca");
		assertEquals(1, primerElemento.intValue(), 
            "El primer elemento es el último que se saca");
	} catch (Exception e) {
		fail("Se produjo una excepción inesperada.");
	}
  }
}
