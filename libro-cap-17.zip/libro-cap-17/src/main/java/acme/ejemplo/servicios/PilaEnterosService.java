package acme.ejemplo.servicios;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class PilaEnterosService {
  private List<Integer> lista = null;
  public PilaEnterosService() {
	this.lista = new ArrayList<>();
  }

  public void meter(Integer valor) {
	this.lista.add(valor);
  }

  public Integer sacar() throws Exception {
	if (lista.size() > 0) {
		Integer elemento = lista.get(lista.size() - 1);
		lista.remove(lista.size() - 1);
		return elemento;
	} else {
		throw new Exception("PILA VACIA");
	}
  }

  public int numeroElementos() {
	return this.lista.size();
  }
}
