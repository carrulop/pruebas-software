  insert into clientes(id, nombre, telefono)
              values(2, 'Elena', '9511888');
  insert into clientes(id, nombre, telefono) 
              values(4, 'Madeleine', '9511222');
  insert into clientes(id, nombre, telefono) 
              values(5, 'Arlen', '614012588');
  insert into clientes(id, nombre, telefono) 
              values(6, 'Phobos', '981223001');
