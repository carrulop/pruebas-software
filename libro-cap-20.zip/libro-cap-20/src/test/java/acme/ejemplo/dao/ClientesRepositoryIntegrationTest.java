package acme.ejemplo.dao;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.jdbc.Sql;
import acme.ejemplo.dao.ClienteRepository;
import acme.ejemplo.entity.ClienteEntity;

@SpringBootTest  // (1)
public class ClientesRepositoryIntegrationTest {

	@Autowired     // (2)
	private ClienteRepository repository;
	
	@Test
	@Sql(scripts = "/bd/test-user-data.sql")   // (3)
	void testListaClientes() {
	  // Llamamos al método bajo prueba  (4)
      List<ClienteEntity> filtrados =          
                   repository.consultarPorNombre("ele");

	  // Verificamos el resultado  (5)
     assertEquals(2, filtrados.size());
     assertEquals("Elena", filtrados.get(0).getNombre());
     assertEquals("Madeleine", filtrados.get(1).getNombre());
	}
}
