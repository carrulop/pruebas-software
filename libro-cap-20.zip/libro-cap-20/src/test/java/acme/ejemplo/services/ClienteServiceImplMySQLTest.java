package acme.ejemplo.services;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import acme.ejemplo.dtos.ClienteDto;
import acme.ejemplo.services.ClientesService;

@SpringBootTest // (1)
public class ClienteServiceImplMySQLTest {

  private static final String NOMBRE = "Arlen";
  private static final String TELEFONO = "951234888";

  @Autowired // (2)
  private ClientesService service;
	
  @Test
  void testServicioClientes() {
     // Primero se añade el cliente: // (3)
	ClienteDto cliente = new ClienteDto(null, NOMBRE,                                               
                                         TELEFONO);
	ClienteDto clienteBd = service.nuevoCliente(cliente);

     // Se verifica que se ha añadido bien  (4)
	Integer idCliente = clienteBd.getId();
	assertTrue(idCliente != null);
	assertEquals(NOMBRE, clienteBd.getNombre());
	assertEquals(TELEFONO, clienteBd.getTelefono());
	clienteBd = service.buscarCliente(idCliente)
                         .orElse(null); // (5)
	assertNotNull(clienteBd);
	assertEquals(idCliente, clienteBd.getId());
	assertEquals(NOMBRE, clienteBd.getNombre());
	assertEquals(TELEFONO, clienteBd.getTelefono());

	List<ClienteDto> lista = service.recuperarTodos();// (6)
	assertTrue(lista.size() > 0);
	clienteBd = lista.stream()
			 .filter(cl -> cl.getId().equals(idCliente))
			 .findFirst()
			 .orElse(null);
	assertNotNull(clienteBd);
	assertEquals(NOMBRE, clienteBd.getNombre());
	assertEquals(TELEFONO, clienteBd.getTelefono());
  }	
}
