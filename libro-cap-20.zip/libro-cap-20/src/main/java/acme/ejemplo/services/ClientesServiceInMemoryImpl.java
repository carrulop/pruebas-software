package acme.ejemplo.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Service;

import acme.ejemplo.dtos.ClienteDto;

@Service
public class ClientesServiceInMemoryImpl 
                   implements ClientesService {

  int id = 3;
  Map<Integer, ClienteDto> mapClientes = new HashMap<>();
  {
   mapClientes.put(1, new ClienteDto(1, "Arlen", "9512288"));
   mapClientes.put(2, new ClienteDto(2, "Yvonne", "9553788"));
  }

  @Override
  public List<ClienteDto> recuperarTodos() {
	return mapClientes.values().stream().toList();
  }

  @Override
  public Optional<ClienteDto> buscarCliente(Integer id) {
	if (mapClientes.containsKey(id)) {
		return Optional.of(mapClientes.get(id));
	}
	return Optional.empty();
  }

  @Override
  public ClienteDto nuevoCliente(ClienteDto cliente) {	
	cliente.setId(this.id++);
	mapClientes.put(cliente.getId(), cliente);
	return cliente;
  }

  @Override
  public boolean eliminarCliente(Integer id) {
	if (mapClientes.containsKey(id)) {
		mapClientes.remove(id);
		return true;
	}
	return false;
  }
}
