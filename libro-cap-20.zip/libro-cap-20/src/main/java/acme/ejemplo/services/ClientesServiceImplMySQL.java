package acme.ejemplo.services;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.context.annotation.Primary;
import acme.ejemplo.dao.ClienteRepository;
import acme.ejemplo.dtos.ClienteDto;
import acme.ejemplo.entity.ClienteEntity;

@Service
@Primary
public class ClientesServiceImplMySQL
               implements ClientesService {

	@Autowired
	ClienteRepository repository;
	
	@Override
	public List<ClienteDto> recuperarTodos() {
     return repository.findAll().stream().map(
                       ClienteDto::new).toList();
	}

	@Override
	public Optional<ClienteDto> buscarCliente(Integer id) {
     return repository.findById(id).map(ClienteDto::new);
	}

	@Override
	public ClienteDto nuevoCliente(ClienteDto cliente) {
	  ClienteEntity entity = new ClienteEntity();
	  entity.setNombre(cliente.getNombre());
	  entity.setTelefono(cliente.getTelefono());
     ClienteEntity result = repository.save(entity);
     return new ClienteDto(result);
	}

	@Override
	public boolean eliminarCliente(Integer id) {
  Optional<ClienteEntity> clienteBd = repository
                                       .findById(id);
     if (clienteBd.isPresent()) {
     	repository.delete(clienteBd.get());
  }
  return clienteBd.isPresent();
	}
}
