package acme.ejemplo.dtos;

import acme.ejemplo.entity.ClienteEntity;
import jakarta.validation.constraints.NotBlank;

public class ClienteDto {

private Integer id;
	
	@NotBlank(message = "Nombre es obligatorio")
	private String nombre;
	
	@NotBlank(message = "Telefono es obligatorio")
	private String telefono;
	
	public ClienteDto() {
	}
	
	public ClienteDto(Integer id, String nombre, 
                       String telefono) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.telefono = telefono;
	}
	
	public ClienteDto(ClienteEntity entity) {
		this.id = entity.getId();
		this.nombre = entity.getNombre();
		this.telefono = entity.getTelefono();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	@Override
	public String toString() {
		return "ClienteDto [id=" + id + ", nombre=" + nombre + ", telefono=" + telefono + "]";
	}

}
