package acme.ejemplo.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import acme.ejemplo.dtos.ClienteDto;
import acme.ejemplo.exceptions.AplicacionException;
import acme.ejemplo.exceptions.ClienteNoEncontradoException;
import acme.ejemplo.services.ClientesService;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/clientes")
public class ClientesController {

	private final ClientesService service;

	@Autowired
	public ClientesController(ClientesService clientesService) {
		this.service = clientesService;
	}

	@GetMapping("/")
	public List<ClienteDto> buscarTodos() {
		return service.recuperarTodos();
	}

	@GetMapping("/{id}")
	public ClienteDto buscarCliente(@PathVariable("id") Integer id) throws AplicacionException { // (1)
		Optional<ClienteDto> cliente = service.buscarCliente(id);
		if (cliente.isEmpty()) {
			throw new ClienteNoEncontradoException("Cliente no encontrado");
		}
		return cliente.get();
	}

	@PostMapping("/")
	public ClienteDto altaCliente(@Valid @RequestBody ClienteDto cliente, HttpServletResponse response) 
	           throws AplicacionException {
		ClienteDto clienteBd = service.nuevoCliente(cliente);
		response.setStatus(HttpStatus.CREATED.value());
		return clienteBd;
	}

    @GetMapping("/saludo")
	public String saludar(@RequestParam(value = "nombre",
	                           defaultValue = "") String nombre) {
	    return "Hola " + nombre;
	}


}
