package acme.ejemplo.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.*;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation
       .ResponseEntityExceptionHandler;
import acme.ejemplo.dtos.ErrorDto;
import acme.ejemplo.exceptions.ClienteNoEncontradoException;

@ControllerAdvice  // (1)
public class RestErrorHandler 
       extends ResponseEntityExceptionHandler { // (2)
  @ExceptionHandler(ClienteNoEncontradoException.class)
  public ResponseEntity<Object> handleClienteNoEncontrado(
      ClienteNoEncontradoException ex, WebRequest webRequest) {
	System.out.println("Manejando error 404 para un cliente");
	ErrorDto error = new ErrorDto();
	error.setCodigo("10");
	error.setMensaje("Recurso no encontrado");
	return handleExceptionInternal(ex, error, 
       new HttpHeaders(), HttpStatus.NOT_FOUND, webRequest);
   }
  
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatusCode status, WebRequest request) {
		Map<String, List<String>> body = new HashMap<>();

		List<String> errors = ex.getBindingResult().getFieldErrors().stream()
				.map(DefaultMessageSourceResolvable::getDefaultMessage).collect(Collectors.toList());

		body.put("errors", errors);

		return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
	}

}
