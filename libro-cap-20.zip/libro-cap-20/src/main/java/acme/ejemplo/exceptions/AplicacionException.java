package acme.ejemplo.exceptions;

public class AplicacionException extends Exception {

	public AplicacionException(String mensaje) {
		super(mensaje);
	}
}
