package acme.ejemplo.dao;

import java.util.List;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import acme.ejemplo.entity.ClienteEntity;

@Repository
public interface ClienteRepository extends JpaRepository<ClienteEntity, Integer> {

	@Query(value = "select c from clientes c " 
          + "where lower(c.nombre) " 
          + "like concat('%', lower (:filtro), '%') "
          + "order by c.nombre")
	List<ClienteEntity> consultarPorNombre(
                  @Param("filtro") String filtro);
	
}
