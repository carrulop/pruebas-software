package acme;

import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Test;

public class EjemplosAsuncionTest {

	@Test
	void testDeshabilitado() {
		Assumptions.abort("Este test se ha abortado por un motivo.");
		// A partir de aquí, las sentencias no son ejecutadas
	}

	@Test
	void testValidoEnIntegracionContinua() {

		Assumptions.assumeTrue("CI".equals(System.getenv("ENV")));

		// Resto del contenido del test
		// ...
	}

	@Test
	void testValidoEnEntornoDistitoDeIntegracionContinua() {

		Assumptions.assumeFalse("CI".equals(System.getenv("ENV")));

		// Resto del contenido del test
		// ...
	}

	@Test
	  void testAssumingThat() {
	     Assumptions.assumingThat("CI".equals(System.getenv("ENV")),
	       () -> System.out.println("El entorno es Integración " 
	             + "Continua"));

	   System.out.println("Empieza el test");
	   // Resto del test
	}

}
